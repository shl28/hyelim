# board-login-img-security → board-login-img-security-Oauth 변경 사항

`board-login-img-security`(원본)를 복사해 **Google · 네이버 · 카카오** 소셜 로그인을 추가한 프로젝트가 `board-login-img-security-Oauth` 입니다.  
게시판·이미지 업로드·폼 로그인·BCrypt·세션 인증 흐름은 동일하고, **인증(로그인) 영역만 확장**되었습니다.

---

## 1. 프로젝트 한눈에 비교

| 항목 | board-login-img-security | board-login-img-security-Oauth |
|------|--------------------------|--------------------------------|
| 설명 | 폼 로그인 + Spring Security | 위 + OAuth2 소셜 로그인 |
| 패키지 | `com.example.boardloginimgsecurity` | `com.example.boardloginimgsecurityoauth` |
| Main 클래스 | `BoardLoginImgSecurityApplication` | `BoardLoginImgSecurityOauthApplication` |
| 설정 파일 | `application.properties` | `application.yml` |
| 서버 포트 | **8082** | **8087** (로컬에서 원본과 동시 실행 가능) |
| DB 이름 | `board_login_img_security` | `board_login_img_security_oauth` |
| 업로드 경로 | `~/board-login-img-security-uploads/` | `~/board-login-img-security-oauth-uploads/` |
| 로그인 방식 | 아이디/비밀번호만 | 아이디/비밀번호 + Google/Naver/Kakao |

---

## 2. 의존성 (pom.xml)

### 추가 (Oauth만)

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-oauth2-client</artifactId>
</dependency>
```

### 빌드 플러그인 (Oauth만)

- `spring-boot-maven-plugin`에 main 클래스 명시  
  `com.example.boardloginimgsecurityoauth.BoardLoginImgSecurityOauthApplication`

---

## 3. 패키지·디렉터리 구조

### 동일하게 유지 (로직 거의 동일)

- `domain` — `Board`, `BoardImage` (변경 없음)
- `repository` — `BoardRepository` (변경 없음)
- `service` — `BoardService` (변경 없음)
- `web` — `BoardController`, `AuthController`, `HomeController`, `dto`
- `config` — `WebConfig` (업로드 경로만 프로젝트명 반영)

### 변경·추가

| 원본 | Oauth |
|------|-------|
| `security/LoginUserDetails.java` | **삭제** → `security/LoginUser.java` 로 대체 |
| — | `security/CustomOAuth2UserService.java` **신규** (네이버·카카오 등 OAuth2) |
| — | `security/CustomOidcUserService.java` **신규** (Google OIDC) |
| — | `security/OAuthUserProfile.java` **신규** |
| `UserService` — 회원가입만 | + `registerOrUpdateOAuthUser()` |
| `UserRepository` — username 조회만 | + OAuth·email 조회 메서드 |

---

## 4. 도메인·DB (`User` 엔티티)

### 원본 `User`

- `id`, `username`, `password`, `name`

### Oauth `User` — 필드 추가

| 필드 | 용도 |
|------|------|
| `email` | 소셜 프로필·기존 계정 이메일 연동 (unique, nullable) |
| `oauthProvider` | `google`, `naver`, `kakao` |
| `oauthProviderSubject` | 제공자 쪽 사용자 고유 ID |

소셜 최초 가입 시:

- `username` 예: `google_123456789` (중복 시 suffix)
- `password` — UUID 랜덤값 BCrypt (폼 로그인용이 아님)
- `name` — 소셜에서 받은 표시 이름

---

## 5. Security Principal (핵심 변경)

### 원본: `LoginUserDetails`

- `UserDetails` 구현
- 필드: `id`, `username`, `password`, `displayName`
- 폼 로그인 전용

### Oauth: `LoginUser`

- `UserDetails` + `OAuth2User` + **`OidcUser`** (Google `openid` scope 대응)
- 내부에 `User` 엔티티 보관
- `LoginUser.of(user)` — 폼 로그인
- `LoginUser.ofOAuth(...)` — 네이버·카카오
- `LoginUser.ofOidc(...)` — Google

`LoginUserDetailsService`는 `LoginUser.of(user)` 를 반환하도록 변경.

### `SecurityUtils`

- `currentUsername()` — principal이 `LoginUser`이면 `getUsername()` 사용  
  (OAuth 후에도 게시판 작성자 비교에 DB `username` 사용)

---

## 6. `SecurityConfig` 변경

### 원본

- `formLogin` 만 설정
- `permitAll`: `/`, `/login`, `/register`, `/uploads/**` 등

### Oauth 추가 내용

```java
// URL 허용
.requestMatchers("/oauth2/**", "/login/oauth2/**").permitAll()

// 소셜 로그인
http.oauth2Login(oauth2 -> oauth2
    .loginPage("/login")
    .defaultSuccessUrl("/home", true)
    .userInfoEndpoint(userInfo -> userInfo
        .userService(customOAuth2UserService)      // OAuth2
        .oidcUserService(customOidcUserService)));   // Google OIDC
```

- `CustomOAuth2UserService`, `CustomOidcUserService` — `@Lazy` 주입 (순환 참조 방지)

---

## 7. 소셜 로그인 처리 흐름

```mermaid
sequenceDiagram
    participant U as 사용자
    participant L as /login
    participant O as OAuth 제공자
    participant S as CustomOAuth2/OidcUserService
    participant US as UserService
    participant H as /home

    U->>L: Google/Naver/Kakao 버튼
    L->>O: 인가 요청
    O->>S: 콜백 + 사용자 정보
    S->>US: registerOrUpdateOAuthUser
    US-->>S: User 저장/갱신
    S-->>H: LoginUser principal
```

1. `/login` 에서 `/oauth2/authorization/{provider}` 링크
2. 콜백 `/login/oauth2/code/{provider}`
3. **Google** → `CustomOidcUserService` → `LoginUser.ofOidc`
4. **Naver/Kakao** → `CustomOAuth2UserService` → `LoginUser.ofOAuth`
5. 성공 시 `/home` (폼 로그인과 동일)

`UserService.registerOrUpdateOAuthUser` 로직:

1. `(oauthProvider + oauthProviderSubject)` 로 기존 회원 조회 → 있으면 이름·이메일 갱신  
2. 없으면 **동일 email** 일반 회원에 OAuth 연동  
3. 없으면 **신규 회원** 생성  

---

## 8. 설정 파일

### 원본 `application.properties`

- 단일 properties 파일
- OAuth 설정 없음

### Oauth `application.yml`

- `spring.security.oauth2.client.registration` — google, naver, kakao
- `spring.security.oauth2.client.provider` — naver, kakao 커스텀 URI
- 클라이언트 ID/Secret은 **환경 변수** (Git에 secret 금지)

```yaml
client-id: ${GOOGLE_CLIENT_ID:change-me}
client-secret: ${GOOGLE_CLIENT_SECRET:change-me}
```

로컬 실행 예 (PowerShell):

```powershell
$env:GOOGLE_CLIENT_ID="발급값"
$env:GOOGLE_CLIENT_SECRET="발급값"
cd board-login-img-security-Oauth
.\mvnw.cmd spring-boot:run
```

Redirect URI (포트 8087 기준):

| 제공자 | URI |
|--------|-----|
| Google | `http://localhost:8087/login/oauth2/code/google` |
| Naver | `http://localhost:8087/login/oauth2/code/naver` |
| Kakao | `http://localhost:8087/login/oauth2/code/kakao` |

자세한 콘솔 설정은 [소셜-로그인-설정.md](./소셜-로그인-설정.md) 참고 (문서 내 포트는 필요 시 8087로 맞출 것).

---

## 9. 화면(Template) 변경

### `login.html`

- 기존: 폼 로그인 + 회원가입 링크
- Oauth 추가: 소셜 로그인 블록

```html
<a th:href="@{/oauth2/authorization/google}">Google로 로그인</a>
<a th:href="@{/oauth2/authorization/naver}">네이버로 로그인</a>
<a th:href="@{/oauth2/authorization/kakao}">카카오로 로그인</a>
```

### `home.html`

- 환영 문구: `#authentication.principal.displayName`, `principal.username`
- principal이 항상 `LoginUser`이어야 함 (Google OIDC는 `CustomOidcUserService`로 통일)

### 그 외 게시판 템플릿

- `board/list`, `detail`, `write`, `edit` 등 — **변경 없음**

---

## 10. 컨트롤러·게시판

`BoardController`, `BoardService` — **원본과 동일한 URL·권한 규칙**

- 목록/상세: 비로그인 조회 가능
- 글쓰기·수정·삭제: `authenticated()` + `SecurityUtils.currentUsername()` 으로 작성자 확인

소셜 로그인 사용자도 DB `username`(예: `google_xxx`)으로 글 작성·수정 가능.

---

## 11. 신규 파일 목록 (Oauth)

```
board-login-img-security-Oauth/
├── docs/
│   ├── board-login-img-security-vs-Oauth-변경사항.md   ← 이 문서
│   └── 소셜-로그인-설정.md
└── src/main/java/.../security/
    ├── LoginUser.java
    ├── CustomOAuth2UserService.java
    ├── CustomOidcUserService.java
    └── OAuthUserProfile.java
```

---

## 12. Git·운영 시 주의 (Oauth 프로젝트에서 겪은 이슈)

1. **`build/`, `target/`, `.gradle/` 커밋 금지**  
   빌드 산출물 `application.yml`에 예전 secret이 남으면 GitHub Push Protection에 걸림.
2. **OAuth Client Secret은 yml에 직접 넣지 말 것** — 환경 변수 또는 로컬 전용 `application-local.yml` + `.gitignore`
3. 노출된 secret은 Google Cloud Console에서 **재발급** 권장

---

## 13. 실행 비교

| | 원본 | Oauth |
|---|------|-------|
| 실행 | `cd board-login-img-security` → `mvnw spring-boot:run` | `cd board-login-img-security-Oauth` → `mvnw spring-boot:run` |
| 접속 | http://localhost:8082 | http://localhost:8087 |
| 로그인 | http://localhost:8082/login | http://localhost:8087/login |

두 프로젝트를 동시에 띄워도 포트·DB·업로드 폴더가 달라 충돌하지 않습니다.

---

## 14. 요약

| 구분 | 변경 여부 |
|------|-----------|
| 게시판 CRUD·이미지 | 동일 |
| 폼 회원가입·BCrypt 로그인 | 동일 |
| Security 세션·URL 권한 | 동일 + OAuth URL 허용 |
| User 엔티티 | OAuth 필드 추가 |
| Principal | `LoginUserDetails` → `LoginUser` |
| 로그인 UI | 소셜 버튼 3개 추가 |
| 설정 | properties → yml + OAuth2 client |

**한 줄 요약:** `board-login-img-security-Oauth` = 원본 게시판 앱 + **소셜 로그인(OAuth2/OIDC)과 회원 연동 로직**이 추가된 버전입니다.
