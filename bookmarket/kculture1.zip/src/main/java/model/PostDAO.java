package model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PostDAO {

    // 게시글 목록 조회
    public List<PostDTO> list(int categoryId, int start, int size) throws Exception {
        List<PostDTO> list = new ArrayList<>();

        String sql = """
            SELECT p.*, 
                   m.name AS member_name, 
                   c.name_en AS category_name, 
                   c.icon AS category_icon
            FROM post p
            JOIN member m ON p.member_id = m.id
            JOIN category c ON p.category_id = c.id
            """;

        if (categoryId > 0) {
            sql += " WHERE p.category_id = ? ";
        }

        sql += " ORDER BY p.created_at DESC LIMIT ?, ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            int idx = 1;

            if (categoryId > 0) {
                ps.setInt(idx++, categoryId);
            }

            ps.setInt(idx++, start);
            ps.setInt(idx, size);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapPost(rs));
                }
            }
        }

        return list;
    }

    // 게시글 매핑
    private PostDTO mapPost(ResultSet rs) throws SQLException {
        PostDTO dto = new PostDTO();

        dto.setId(rs.getInt("id"));
        dto.setCategoryId(rs.getInt("category_id"));
        dto.setMemberId(rs.getInt("member_id"));
        dto.setTitle(rs.getString("title"));
        dto.setContent(rs.getString("content"));
        dto.setImageFilename(rs.getString("image_filename"));
        dto.setViewCount(rs.getInt("view_count"));
        dto.setCreatedAt(rs.getTimestamp("created_at"));
        dto.setUpdatedAt(rs.getTimestamp("updated_at"));

        // join 데이터 (try-catch 제거)
        dto.setMemberName(rs.getString("member_name"));
        dto.setCategoryName(rs.getString("category_name"));
        dto.setCategoryIcon(rs.getString("category_icon"));

        return dto;
    }

    // 게시글 개수
    public int count(int categoryId) throws Exception {
        String sql = (categoryId > 0)
                ? "SELECT COUNT(*) FROM post WHERE category_id = ?"
                : "SELECT COUNT(*) FROM post";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            if (categoryId > 0) {
                ps.setInt(1, categoryId);
            }

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    // 게시글 등록
    public int insert(PostDTO dto) throws Exception {
        String sql = "INSERT INTO post (category_id, member_id, title, content, image_filename) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, dto.getCategoryId());
            ps.setInt(2, dto.getMemberId());
            ps.setString(3, dto.getTitle());
            ps.setString(4, dto.getContent());
            ps.setString(5, dto.getImageFilename());

            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    // 게시글 수정
    public void update(PostDTO dto) throws Exception {
        String sql = "UPDATE post SET title = ?, content = ?, image_filename = ? WHERE id = ? AND member_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, dto.getTitle());
            ps.setString(2, dto.getContent());
            ps.setString(3, dto.getImageFilename());
            ps.setInt(4, dto.getId());
            ps.setInt(5, dto.getMemberId());

            ps.executeUpdate();
        }
    }

    // 게시글 상세 조회
    public PostDTO findById(int id) throws Exception {
        String sql = """
            SELECT p.*, 
                   m.name AS member_name, 
                   m.nationality,
                   c.name_en AS category_name, 
                   c.icon AS category_icon
            FROM post p
            JOIN member m ON p.member_id = m.id
            JOIN category c ON p.category_id = c.id
            WHERE p.id = ?
            """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapPost(rs) : null;
            }
        }
    }

    // 조회수 증가
    public void increaseView(int id) throws Exception {
        String sql = "UPDATE post SET view_count = view_count + 1 WHERE id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    // 게시글 삭제
    public void delete(int id, int memberId) throws Exception {
        String sql = "DELETE FROM post WHERE id = ? AND member_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.setInt(2, memberId);
            ps.executeUpdate();
        }
    }
}