package model;

import java.sql.*;

public class MemberDAO {

    // 로그인
    public MemberDTO login(String email, String password) throws Exception {
        String sql = "SELECT * FROM member WHERE email = ? AND password = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, email);
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapMember(rs) : null;
            }
        }
    }

    // 회원가입
    public int join(MemberDTO dto) throws Exception {
        String sql = """
            INSERT INTO member (email, password, name, nationality, language)
            VALUES (?, ?, ?, ?, ?)
            """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, dto.getEmail());
            ps.setString(2, dto.getPassword());
            ps.setString(3, dto.getName());
            ps.setString(4, dto.getNationality());
            ps.setString(5, dto.getLanguage() != null ? dto.getLanguage() : "en");

            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    // ID로 조회
    public MemberDTO findById(int id) throws Exception {
        String sql = "SELECT * FROM member WHERE id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapMember(rs) : null;
            }
        }
    }

    // 이메일 존재 여부
    public boolean existsEmail(String email) throws Exception {
        String sql = "SELECT COUNT(*) FROM member WHERE email = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, email);

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }

    // 공통 매핑
    private MemberDTO mapMember(ResultSet rs) throws SQLException {
        MemberDTO dto = new MemberDTO();

        dto.setId(rs.getInt("id"));
        dto.setEmail(rs.getString("email"));
        dto.setPassword(rs.getString("password"));
        dto.setName(rs.getString("name"));
        dto.setNationality(rs.getString("nationality"));
        dto.setLanguage(rs.getString("language"));

        return dto;
    }
}