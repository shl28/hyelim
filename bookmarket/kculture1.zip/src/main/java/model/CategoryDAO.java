package model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CategoryDAO {

    // 전체 카테고리 조회
    public List<CategoryDTO> list() throws Exception {
        List<CategoryDTO> list = new ArrayList<>();

        String sql = "SELECT * FROM category ORDER BY sort_order";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(mapCategory(rs));
            }
        }

        return list;
    }

    // ID로 조회
    public CategoryDTO findById(int id) throws Exception {
        String sql = "SELECT * FROM category WHERE id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapCategory(rs) : null;
            }
        }
    }

    // 코드로 조회
    public CategoryDTO findByCode(String code) throws Exception {
        String sql = "SELECT * FROM category WHERE code = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, code);

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapCategory(rs) : null;
            }
        }
    }

    // ResultSet → DTO 변환
    private CategoryDTO mapCategory(ResultSet rs) throws SQLException {
        CategoryDTO dto = new CategoryDTO();

        dto.setId(rs.getInt("id"));
        dto.setCode(rs.getString("code"));
        dto.setNameEn(rs.getString("name_en"));
        dto.setNameKo(rs.getString("name_ko"));
        dto.setIcon(rs.getString("icon"));
        dto.setSortOrder(rs.getInt("sort_order"));

        return dto;
    }
}