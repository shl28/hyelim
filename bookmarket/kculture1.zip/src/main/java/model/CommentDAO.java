package model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CommentDAO {

    // 댓글 목록 조회
    public List<CommentDTO> listByPostId(int postId) throws Exception {
        List<CommentDTO> list = new ArrayList<>();

        String sql = """
            SELECT c.*, 
                   m.name AS member_name, 
                   m.nationality
            FROM comment c
            JOIN member m ON c.member_id = m.id
            WHERE c.post_id = ?
            ORDER BY c.created_at
            """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, postId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapComment(rs));
                }
            }
        }

        return list;
    }

    // 댓글 등록
    public int insert(CommentDTO dto) throws Exception {
        String sql = "INSERT INTO comment (post_id, member_id, content) VALUES (?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, dto.getPostId());
            ps.setInt(2, dto.getMemberId());
            ps.setString(3, dto.getContent());

            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    // ResultSet → DTO 매핑
    private CommentDTO mapComment(ResultSet rs) throws SQLException {
        CommentDTO dto = new CommentDTO();

        dto.setId(rs.getInt("id"));
        dto.setPostId(rs.getInt("post_id"));
        dto.setMemberId(rs.getInt("member_id"));
        dto.setContent(rs.getString("content"));
        dto.setCreatedAt(rs.getTimestamp("created_at"));

        // try-catch 제거 (SQL에서 이미 보장됨)
        dto.setMemberName(rs.getString("member_name"));
        dto.setNationality(rs.getString("nationality"));

        return dto;
    }
}