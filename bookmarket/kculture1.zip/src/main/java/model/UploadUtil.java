package model;

import jakarta.servlet.http.Part;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.*;
import java.util.UUID;

public class UploadUtil {

    private static final long MAX_BYTES = 5 * 1024 * 1024;

    private UploadUtil() {}

    // 이미지 저장
    public static String savePostImage(Part part, Path uploadDir) throws IOException {

        // 1. 파일 존재 체크
        if (part == null || part.getSize() <= 0) {
            return null;
        }

        // 2. 용량 제한
        if (part.getSize() > MAX_BYTES) {
            throw new IOException("Image exceeds 5MB limit.");
        }

        // 3. 파일명
        String submitted = part.getSubmittedFileName();
        if (submitted == null || submitted.isBlank()) {
            return null;
        }

        // 4. 확장자 검사
        String ext = safeExtension(submitted);
        if (ext == null) {
            throw new IOException("Invalid file extension.");
        }

        // 5. MIME 타입 검사 (브라우저 기반)
        String ct = part.getContentType();
        if (ct == null || !allowedContentType(ct)) {
            throw new IOException("Invalid content type.");
        }

        // 6. 업로드 폴더 생성
        Files.createDirectories(uploadDir);

        // 7. 랜덤 파일명 생성
        String filename = UUID.randomUUID().toString().replace("-", "") + "." + ext;

        Path target = uploadDir.resolve(filename).normalize();

        // 8. 경로 공격 방지
        Path base = uploadDir.normalize();
        if (!target.startsWith(base)) {
            throw new IOException("Invalid upload path.");
        }

        // 9. 파일 저장 (덮어쓰기 방지 옵션)
        try (InputStream in = part.getInputStream()) {
            Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
        }

        // 10. 실제 파일 타입 검사 (추가 보안)
        String detectedType = Files.probeContentType(target);
        if (detectedType == null || !allowedContentType(detectedType)) {
            Files.deleteIfExists(target); // 잘못된 파일이면 삭제
            throw new IOException("File content type mismatch.");
        }

        return filename;
    }

    // 파일 삭제
    public static void deleteIfExists(Path uploadDir, String filename) {
        if (filename == null || filename.isEmpty()) return;

        // 경로 공격 방지
        if (filename.contains("..") || filename.contains("/") || filename.contains("\\")) {
            return;
        }

        try {
            Path base = uploadDir.normalize();
            Path target = base.resolve(filename).normalize();

            if (target.startsWith(base)) {
                Files.deleteIfExists(target);
            }
        } catch (Exception ignored) {}
    }

    // MIME 허용 리스트
    private static boolean allowedContentType(String ct) {
        return "image/jpeg".equalsIgnoreCase(ct)
            || "image/png".equalsIgnoreCase(ct)
            || "image/gif".equalsIgnoreCase(ct)
            || "image/webp".equalsIgnoreCase(ct);
    }

    // 확장자 검사
    private static String safeExtension(String name) {
        int i = name.lastIndexOf('.');
        if (i < 0 || i >= name.length() - 1) {
            return null;
        }

        String ext = name.substring(i + 1).toLowerCase();

        return switch (ext) {
            case "jpg", "jpeg" -> "jpg";
            case "png" -> "png";
            case "gif" -> "gif";
            case "webp" -> "webp";
            default -> null;
        };
    }
}