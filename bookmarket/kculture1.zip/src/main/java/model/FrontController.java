package model;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@WebServlet("*.do")
@MultipartConfig(
    fileSizeThreshold = 0,
    maxFileSize = 5 * 1024 * 1024,
    maxRequestSize = 12 * 1024 * 1024
)
public class FrontController extends HttpServlet {

    private MemberDAO memberDAO = new MemberDAO();
    private CategoryDAO categoryDAO = new CategoryDAO();
    private PostDAO postDAO = new PostDAO();
    private CommentDAO commentDAO = new CommentDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        process(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        process(request, response);
    }

    private void process(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String action = getAction(request);
        String view = null;

        try {
            // 공통 데이터
            request.setAttribute("categories", categoryDAO.list());

            switch (action) {

                case "list":
                    view = handleList(request);
                    break;

                case "view":
                    view = handleView(request, response);
                    break;

                case "write":
                    if (requireLogin(request, response) == null) return;
                    view = "/write.jsp";
                    break;

                case "writeProcess":
                    handleWriteProcess(request, response);
                    return;

                case "edit":
                    view = handleEdit(request, response);
                    break;

                case "editProcess":
                    handleEditProcess(request, response);
                    return;

                case "delete":
                    handleDelete(request, response);
                    return;

                case "commentProcess":
                    handleComment(request, response);
                    return;

                case "login":
                    view = "/login.jsp";
                    break;

                case "loginProcess":
                    handleLogin(request, response);
                    return;

                case "logout":
                    request.getSession().invalidate();
                    response.sendRedirect("list.do");
                    return;

                case "join":
                    view = "/join.jsp";
                    break;

                case "joinProcess":
                    handleJoin(request, response);
                    return;

                default:
                    response.sendRedirect("list.do");
                    return;
            }

        } catch (Exception e) {
            throw new ServletException(e);
        }

        if (view != null) {
            request.getRequestDispatcher(view).forward(request, response);
        }
    }

    // ================= 기능 메서드 =================

    private String handleList(HttpServletRequest request) throws Exception {
        int catId = parseInt(request.getParameter("categoryId"), 0);
        int page = parseInt(request.getParameter("page"), 1);

        int pageSize = 10;
        int start = (page - 1) * pageSize;

        List<PostDTO> list = postDAO.list(catId, start, pageSize);

        int total = postDAO.count(catId);
        int totalPages = (int) Math.ceil((double) total / pageSize);

        request.setAttribute("list", list);
        request.setAttribute("categoryId", catId);
        request.setAttribute("currentPage", page);
        request.setAttribute("totalPages", totalPages);

        return "/list.jsp";
    }

    private String handleView(HttpServletRequest request, HttpServletResponse response) throws Exception {
        int postId = parseInt(request.getParameter("id"), 0);

        if (postId <= 0) {
            response.sendRedirect("list.do");
            return null;
        }

        PostDTO post = postDAO.findById(postId);

        if (post == null) {
            response.sendRedirect("list.do");
            return null;
        }

        postDAO.increaseView(postId);
        post.setViewCount(post.getViewCount() + 1);

        List<CommentDTO> comments = commentDAO.listByPostId(postId);

        request.setAttribute("post", post);
        request.setAttribute("comments", comments);

        return "/view.jsp";
    }

    private void handleWriteProcess(HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        MemberDTO login = requireLogin(request, response);
        if (login == null) return;

        PostDTO dto = new PostDTO();

        dto.setCategoryId(parseInt(request.getParameter("categoryId"), 1));
        dto.setMemberId(login.getId());
        dto.setTitle(request.getParameter("title"));
        dto.setContent(request.getParameter("content"));

        Path uploadDir = resolveUploadDir();

        try {
            Part image = request.getPart("image");
            dto.setImageFilename(UploadUtil.savePostImage(image, uploadDir));
        } catch (Exception e) {
            request.setAttribute("error", e.getMessage());
            request.getRequestDispatcher("/write.jsp").forward(request, response);
            return;
        }

        int id = postDAO.insert(dto);
        response.sendRedirect("view.do?id=" + id);
    }

    private String handleEdit(HttpServletRequest request, HttpServletResponse response) throws Exception {
        MemberDTO login = requireLogin(request, response);
        if (login == null) return null;

        int id = parseInt(request.getParameter("id"), 0);
        PostDTO post = postDAO.findById(id);

        if (post == null || post.getMemberId() != login.getId()) {
            response.sendRedirect("list.do");
            return null;
        }

        request.setAttribute("post", post);
        return "/edit.jsp";
    }

    private void handleEditProcess(HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        MemberDTO login = requireLogin(request, response);
        if (login == null) return;

        int id = parseInt(request.getParameter("id"), 0);
        PostDTO existing = postDAO.findById(id);

        if (existing == null || existing.getMemberId() != login.getId()) {
            response.sendRedirect("list.do");
            return;
        }

        Path uploadDir = resolveUploadDir();
        String imageFn = existing.getImageFilename();

        try {
            Part image = request.getPart("image");

            if (image != null && image.getSize() > 0) {
                UploadUtil.deleteIfExists(uploadDir, imageFn);
                imageFn = UploadUtil.savePostImage(image, uploadDir);
            } else if ("1".equals(request.getParameter("removeImage"))) {
                UploadUtil.deleteIfExists(uploadDir, imageFn);
                imageFn = null;
            }

        } catch (Exception e) {
            request.setAttribute("error", e.getMessage());
            request.setAttribute("post", existing);
            request.getRequestDispatcher("/edit.jsp").forward(request, response);
            return;
        }

        PostDTO dto = new PostDTO();
        dto.setId(id);
        dto.setMemberId(login.getId());
        dto.setTitle(request.getParameter("title"));
        dto.setContent(request.getParameter("content"));
        dto.setImageFilename(imageFn);

        postDAO.update(dto);

        response.sendRedirect("view.do?id=" + id);
    }

    private void handleDelete(HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        MemberDTO login = requireLogin(request, response);
        if (login == null) return;

        int id = parseInt(request.getParameter("id"), 0);
        PostDTO post = postDAO.findById(id);

        if (post != null && post.getMemberId() == login.getId()) {
            UploadUtil.deleteIfExists(resolveUploadDir(), post.getImageFilename());
        }

        postDAO.delete(id, login.getId());
        response.sendRedirect("list.do");
    }

    private void handleComment(HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        MemberDTO login = requireLogin(request, response);
        if (login == null) return;

        CommentDTO dto = new CommentDTO();

        dto.setPostId(parseInt(request.getParameter("postId"), 0));
        dto.setMemberId(login.getId());
        dto.setContent(request.getParameter("content"));

        commentDAO.insert(dto);

        response.sendRedirect("view.do?id=" + dto.getPostId());
    }

    private void handleLogin(HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        MemberDTO m = memberDAO.login(email, password);

        if (m != null) {
            request.getSession().setAttribute("loginMember", m);
            response.sendRedirect("list.do");
        } else {
            request.setAttribute("error", "Invalid email or password.");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
        }
    }

    private void handleJoin(HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        MemberDTO dto = new MemberDTO();

        dto.setEmail(request.getParameter("email"));
        dto.setPassword(request.getParameter("password"));
        dto.setName(request.getParameter("name"));
        dto.setNationality(request.getParameter("nationality"));
        dto.setLanguage(request.getParameter("language"));

        if (memberDAO.existsEmail(dto.getEmail())) {
            request.setAttribute("error", "Email already exists.");
            request.getRequestDispatcher("/join.jsp").forward(request, response);
            return;
        }

        memberDAO.join(dto);
        response.sendRedirect("login.do");
    }

    // ================= 공통 =================

    private String getAction(HttpServletRequest request) {
        String uri = request.getRequestURI();
        return uri.substring(uri.lastIndexOf("/") + 1).replace(".do", "");
    }

    private int parseInt(String s, int def) {
        try {
            return (s == null || s.isEmpty()) ? def : Integer.parseInt(s);
        } catch (Exception e) {
            return def;
        }
    }

    private MemberDTO getLoginMember(HttpServletRequest request) {
        return (MemberDTO) request.getSession().getAttribute("loginMember");
    }

    private MemberDTO requireLogin(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        MemberDTO login = getLoginMember(request);

        if (login == null) {
            response.sendRedirect("login.do");
        }

        return login;
    }

    private Path resolveUploadDir() {
        String real = getServletContext().getRealPath("/uploads");

        if (real != null) {
            return Paths.get(real);
        }

        return Paths.get(System.getProperty("java.io.tmpdir"), "kculture_uploads");
    }
}