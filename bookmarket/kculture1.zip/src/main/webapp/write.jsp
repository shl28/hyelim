<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Write Post - K-Culture Platform</title>

<link rel="stylesheet" href="${pageContext.request.contextPath}/css/write.css">
<script src="${pageContext.request.contextPath}/js/write.js" defer></script>
</head>

<body>

<div class="header">
	<a href="${pageContext.request.contextPath}/list.do">← Back to List</a>
</div>

<div class="container">
	<h1>📝 Write Post</h1>

	<!-- 에러 메시지 -->
	<c:if test="${not empty error}">
		<div class="error">${error}</div>
	</c:if>

	<form action="${pageContext.request.contextPath}/writeProcess.do"
	      method="post"
	      enctype="multipart/form-data">

		<!-- 카테고리 -->
		<div class="form-group">
			<label>Category</label>

			<select name="categoryId" required>

				<c:choose>
					<c:when test="${empty categories}">
						<option value="">(No categories)</option>
					</c:when>

					<c:otherwise>
						<c:forEach var="c" items="${categories}">
							<option value="${c.id}">
								${c.icon} ${c.nameEn} - ${c.nameKo}
							</option>
						</c:forEach>
					</c:otherwise>
				</c:choose>

			</select>
		</div>

		<!-- 제목 -->
		<div class="form-group">
			<label>Title</label>
			<input type="text" name="title" required placeholder="Post title">
		</div>

		<!-- 내용 -->
		<div class="form-group">
			<label>Content</label>
			<textarea name="content"
			          placeholder="Share your K-Culture experience..."
			          required></textarea>
		</div>

		<!-- 이미지 -->
		<div class="form-group">
			<label>Image (optional)</label>
			<input type="file" name="image"
			       accept="image/jpeg,image/png,image/gif,image/webp">
			<p class="hint">JPEG, PNG, GIF, WebP · max 5MB</p>
		</div>

		<!-- 버튼 -->
		<div>
			<button type="submit" class="btn btn-primary">Post</button>
			<a href="${pageContext.request.contextPath}/list.do"
			   class="btn btn-secondary">Cancel</a>
		</div>

	</form>
</div>

</body>
</html>