<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>${post.title} - K-Culture Platform</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/view.css">
</head>

<body>

<!-- HEADER -->
<div class="header">
	<div class="logo">🇰🇷 K-Culture Platform</div>
	<nav class="nav">
		<a href="${pageContext.request.contextPath}/list.do">Home</a>

		<c:choose>
			<c:when test="${not empty sessionScope.loginMember}">
				<span>${sessionScope.loginMember.name}</span>
				<a href="${pageContext.request.contextPath}/logout.do">Logout</a>
			</c:when>
			<c:otherwise>
				<a href="${pageContext.request.contextPath}/login.do">Login</a>
			</c:otherwise>
		</c:choose>
	</nav>
</div>

<div class="container">

	<!-- 게시글 -->
	<div class="post-header">
		<div class="post-cat">
			${post.categoryIcon} ${post.categoryName}
		</div>

		<h1 class="post-title">${post.title}</h1>

		<div class="post-meta">
			${post.memberName} · 👁 ${post.viewCount} · ${post.createdAt}
		</div>
	</div>

	<!-- 이미지 -->
	<c:if test="${not empty post.imageFilename}">
		<img class="post-image"
		     src="${pageContext.request.contextPath}/uploads/${post.imageFilename}">
	</c:if>

	<!-- 내용 -->
	<div class="post-content">${post.content}</div>

	<!-- 버튼 -->
	<div class="post-actions">
		<a href="${pageContext.request.contextPath}/list.do" class="btn btn-secondary">← List</a>

		<c:if test="${not empty sessionScope.loginMember and sessionScope.loginMember.id == post.memberId}">
			<a href="${pageContext.request.contextPath}/edit.do?id=${post.id}" class="btn btn-secondary">Edit</a>
			<a href="${pageContext.request.contextPath}/delete.do?id=${post.id}"
			   class="btn btn-primary"
			   onclick="return confirm('Delete this post?');">Delete</a>
		</c:if>
	</div>

	<!-- 댓글 -->
	<div class="comments">
		<h3>💬 Comments (${fn:length(comments)})</h3>

		<c:forEach var="c" items="${comments}">
			<div class="comment-item">
				<div class="comment-meta">
					${c.memberName}
					<c:if test="${not empty c.nationality}">
						(${c.nationality})
					</c:if>
					· ${c.createdAt}
				</div>
				<div>${c.content}</div>
			</div>
		</c:forEach>

		<!-- 댓글 작성 -->
		<c:choose>
			<c:when test="${not empty sessionScope.loginMember}">
				<form class="comment-form"
				      action="${pageContext.request.contextPath}/commentProcess.do"
				      method="post">
					<input type="hidden" name="postId" value="${post.id}">
					<textarea name="content" placeholder="Write a comment..." required></textarea>
					<button type="submit" class="btn btn-primary">Post Comment</button>
				</form>
			</c:when>
			<c:otherwise>
				<p style="color: #888; margin-top: 16px;">
					Please 
					<a href="${pageContext.request.contextPath}/login.do" style="color:#e94560;">
						login
					</a> to comment.
				</p>
			</c:otherwise>
		</c:choose>

	</div>

</div>

</body>
</html>