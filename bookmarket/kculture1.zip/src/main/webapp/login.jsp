<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Login - K-Culture Platform</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/login.css">
</head>

<body>

<div class="login-box">
	<h1>🇰🇷 K-Culture Platform</h1>

	<p style="text-align: center; color: #888; margin-bottom: 24px;">
		Login for Foreign Tourists
	</p>

	<!-- 에러 메시지 -->
	<c:if test="${not empty error}">
		<div class="error">${error}</div>
	</c:if>

	<form action="${pageContext.request.contextPath}/loginProcess.do" method="post">

		<div class="form-group">
			<label>Email</label>
			<input type="email" name="email" value="${param.email}" required placeholder="your@email.com">
		</div>

		<div class="form-group">
			<label>Password</label>
			<input type="password" name="password" required>
		</div>

		<button type="submit" class="btn">Login</button>
	</form>

	<div class="links">
		<a href="${pageContext.request.contextPath}/join.do">Create Account</a> ·
		<a href="${pageContext.request.contextPath}/list.do">Back to Home</a>
	</div>
</div>

</body>
</html>