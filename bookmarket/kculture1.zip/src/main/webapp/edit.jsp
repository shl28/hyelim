<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Edit Post - K-Culture Platform</title>

<link rel="stylesheet" href="${pageContext.request.contextPath}/css/edit.css">
</head>

<body>

<div class="header">
	<a href="${pageContext.request.contextPath}/view.do?id=${post.id}">← Back</a>
</div>

<div class="container">
	<h1>✏️ Edit Post</h1>

	<!-- 에러 -->
	<c:if test="${not empty error}">
		<div class="error">${error}</div>
	</c:if>

	<form action="${pageContext.request.contextPath}/editProcess.do"
	      method="post"
	      enctype="multipart/form-data">

		<input type="hidden" name="id" value="${post.id}">

		<!-- 제목 -->
		<div class="form-group">
			<label>Title</label>
			<input type="text"
			       name="title"
			       value="${post.title}"
			       required>
		</div>

		<!-- 내용 -->
		<div class="form-group">
			<label>Content</label>
			<textarea name="content" required>${post.content}</textarea>
		</div>

		<!-- 이미지 -->
		<div class="form-group">
			<label>Image</label>

			<!-- 기존 이미지 -->
			<c:if test="${not empty post.imageFilename}">
				<div>
					<img class="post-image-preview"
					     src="${pageContext.request.contextPath}/uploads/${post.imageFilename}">
				</div>

				<label class="check-row">
					<input type="checkbox" name="removeImage" value="1">
					Remove current image
				</label>
			</c:if>

			<!-- 새 이미지 -->
			<input type="file"
			       name="image"
			       accept="image/jpeg,image/png,image/gif,image/webp">

			<p class="hint">
				Leave empty to keep current image. JPEG, PNG, GIF, WebP · max 5MB
			</p>
		</div>

		<!-- 버튼 -->
		<div>
			<button type="submit" class="btn btn-primary">Save</button>

			<a href="${pageContext.request.contextPath}/view.do?id=${post.id}"
			   class="btn btn-secondary">Cancel</a>
		</div>

	</form>
</div>

</body>
</html>