(function(){
	var form = document.querySelector('form[action*="writeProcess.do"]');
	
	if(!form) return;  // form 없으면 종료
	
	var fileInput = form.querySelector('input[name="image"]');
	
	if(!fileInput) return;  // 이미지 없으면 종료
	
	var maxBytes = 5 * 1024 * 1024;
	
	form.addEventListener('submit', function (e){
		var f = fileInput.files && fileInput.files[0];   // 첫번째 파일 가져옴
			
			if(f && f.size > maxBytes){
				e.preventDefault();
				alert('Image must be 5MB or smaller.');
			}
	});
})();

/* (function () { ... })();  : 즉시 실행 함수, 페이지 로드 되자마자 실행
 	전역변수 오염 방지
 */
/*
	페이지 로드 -> 코드 실행 -> 폼 찾기 -> 파일 선택 -> 제출 누름 -> 5mb 초과: 제출 불가
 */