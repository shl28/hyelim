<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Join - K-Culture Platform</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/join.css">
</head>

<body>

<div class="join-box">
	<h1>🇰🇷 Join K-Culture Platform</h1>

	<p style="text-align: center; color: #888; margin-bottom: 24px;">
		For Foreign Tourists
	</p>

	<!-- 에러 -->
	<c:if test="${not empty error}">
		<div class="error">${error}</div>
	</c:if>

	<form action="${pageContext.request.contextPath}/joinProcess.do" method="post">

		<!-- 이메일 -->
		<div class="form-group">
			<label>Email</label>
			<input type="email"
			       name="email"
			       value="${param.email}"
			       placeholder="your@email.com"
			       required>
		</div>

		<!-- 비밀번호 -->
		<div class="form-group">
			<label>Password</label>
			<input type="password" name="password" required>
		</div>

		<!-- 이름 -->
		<div class="form-group">
			<label>Name</label>
			<input type="text"
			       name="name"
			       value="${param.name}"
			       placeholder="Your name"
			       required>
		</div>

		<!-- 국적 -->
		<div class="form-group">
			<label>Nationality</label>
			<input type="text"
			       name="nationality"
			       value="${param.nationality}"
			       placeholder="e.g. USA, Japan">
		</div>

		<!-- 언어 -->
		<div class="form-group">
			<label>Language</label>
			<select name="language">

				<option value="en" ${param.language == 'en' ? 'selected' : ''}>English</option>
				<option value="ja" ${param.language == 'ja' ? 'selected' : ''}>日本語</option>
				<option value="zh" ${param.language == 'zh' ? 'selected' : ''}>中文</option>
				<option value="ko" ${param.language == 'ko' ? 'selected' : ''}>한국어</option>

			</select>
		</div>

		<button type="submit" class="btn">Join</button>
	</form>

	<div class="links">
		<a href="${pageContext.request.contextPath}/login.do">Already have account?</a> ·
		<a href="${pageContext.request.contextPath}/list.do">Home</a>
	</div>
</div>

</body>
</html>