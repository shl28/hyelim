<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>K-Culture Platform</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/list.css">
</head>
<body>

<!-- ✅ HEADER -->
<div class="header">
	<div class="logo">🇰🇷 K-Culture Platform</div>
	<nav class="nav">
		<a href="${pageContext.request.contextPath}/list.do">Home</a>

		<c:choose>
			<c:when test="${not empty sessionScope.loginMember}">
				<span>
					${sessionScope.loginMember.name}
					(${empty sessionScope.loginMember.nationality ? 'Visitor' : sessionScope.loginMember.nationality})
				</span>
				<a href="${pageContext.request.contextPath}/write.do">Write</a>
				<a href="${pageContext.request.contextPath}/logout.do">Logout</a>
			</c:when>
			<c:otherwise>
				<a href="${pageContext.request.contextPath}/login.do">Login</a>
				<a href="${pageContext.request.contextPath}/join.do">Join</a>
			</c:otherwise>
		</c:choose>
	</nav>
</div>

<div class="container">
	<h1>Discover K-Culture</h1>
	<p class="subtitle">Community for Foreign Tourists</p>

	<!-- 글쓰기 버튼 -->
	<c:if test="${not empty sessionScope.loginMember}">
		<a href="${pageContext.request.contextPath}/write.do" class="write-btn">+ Write Post</a>
	</c:if>

	<!-- 카테고리 -->
	<div class="categories">
		<a href="${pageContext.request.contextPath}/list.do"
		   class="cat-btn ${categoryId == 0 ? 'active' : ''}">All</a>

		<c:forEach var="c" items="${categories}">
			<a href="${pageContext.request.contextPath}/list.do?categoryId=${c.id}"
			   class="cat-btn ${categoryId == c.id ? 'active' : ''}">
				${c.icon} ${c.nameEn}
			</a>
		</c:forEach>
	</div>

	<!-- 게시글 리스트 -->
	<div class="post-list">

		<c:if test="${empty list}">
			<div class="empty">No posts yet.</div>
		</c:if>

		<c:forEach var="p" items="${list}">
			<div class="post-item">

				<!-- 이미지 -->
				<c:if test="${not empty p.imageFilename}">
					<img class="post-thumb"
					     src="${pageContext.request.contextPath}/uploads/${p.imageFilename}">
				</c:if>

				<!-- 내용 -->
				<div class="post-content">
					<div class="post-title">
						<a href="${pageContext.request.contextPath}/view.do?id=${p.id}">
							${p.title}
						</a>
					</div>
					<div class="post-meta">
						${p.memberName} · ${p.categoryName} · ${p.createdAt}
					</div>
				</div>

				<div>👁 ${p.viewCount}</div>
			</div>
		</c:forEach>

	</div>

	<!-- 페이징 -->
	<c:if test="${totalPages > 1}">
		<div class="pagination">

			<c:if test="${currentPage > 1}">
				<a href="?page=${currentPage - 1}&categoryId=${categoryId}">Prev</a>
			</c:if>

			<c:forEach var="i" begin="1" end="${totalPages}">
				<c:choose>
					<c:when test="${i == currentPage}">
						<span class="current">${i}</span>
					</c:when>
					<c:otherwise>
						<a href="?page=${i}&categoryId=${categoryId}">${i}</a>
					</c:otherwise>
				</c:choose>
			</c:forEach>

			<c:if test="${currentPage < totalPages}">
				<a href="?page=${currentPage + 1}&categoryId=${categoryId}">Next</a>
			</c:if>

		</div>
	</c:if>

</div>

</body>
</html>