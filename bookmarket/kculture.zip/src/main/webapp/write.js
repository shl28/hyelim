(function () {
    var form = document.querySelector('form[action*="writeProcess.do"]');
    if (!form) return;
    var fileInput = form.querySelector('input[name="image"]');
    if (!fileInput) return;
    var maxBytes = 5 * 1024 * 1024;
    form.addEventListener('submit', function (e) {
        var f = fileInput.files && fileInput.files[0];
        if (f && f.size > maxBytes) {
            e.preventDefault();
            alert('Image must be 5MB or smaller.');
        }
    });
})();
