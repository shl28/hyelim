-- =============================================================================
-- K-Culture Platform — 통합 스키마 (schema1.sql)
-- 한 번 실행으로 DB·테이블·카테고리·테스트 계정까지 구성합니다.
-- (기존 schema.sql + 이미지 컬럼 + 확장 카테고리 내용을 하나로 묶은 파일)
--
-- 사용: MySQL / MariaDB 클라이언트에서 전체 실행
-- 주의: 동일 DB(kculture_platform)가 이미 있으면 CREATE DATABASE 는 건너뛰고
--       테이블 생성 시 "already exists" 오류가 날 수 있습니다. 그때는
--       빈 DB에서 실행하거나, 기존 테이블을 백업 후 DROP 후 재실행하세요.
-- =============================================================================

CREATE DATABASE IF NOT EXISTS kculture_platform
    DEFAULT CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE kculture_platform;

SET NAMES utf8mb4;

-- ---------------------------------------------------------------------------
-- 회원
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS member (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    name VARCHAR(50) NOT NULL,
    nationality VARCHAR(50) DEFAULT NULL,
    language VARCHAR(20) DEFAULT 'en',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------------------------
-- 카테고리
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS category (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(30) NOT NULL UNIQUE,
    name_en VARCHAR(50) NOT NULL,
    name_ko VARCHAR(50) NOT NULL,
    icon VARCHAR(20) DEFAULT '📌',
    sort_order INT DEFAULT 0
);

INSERT IGNORE INTO category (code, name_en, name_ko, icon, sort_order) VALUES
('k-food', 'K-Food', '한식', '🍜', 1),
('k-pop', 'K-Pop', '케이팝', '🎵', 2),
('k-drama', 'K-Drama', '드라마', '📺', 3),
('k-movie', 'K-Movie', '한국영화', '🎬', 4),
('k-beauty', 'K-Beauty', 'K뷰티', '💄', 5),
('k-fashion', 'K-Fashion', '패션', '👗', 6),
('travel', 'Travel', '여행', '✈️', 7),
('traditional', 'Traditional', '전통문화', '🏯', 8),
('festivals', 'Festivals', '축제', '🎉', 9),
('accommodation', 'Accommodation', '숙소', '🏨', 10),
('shopping', 'Shopping', '쇼핑', '🛍️', 11),
('nightlife', 'Nightlife', '나이트라이프', '🌃', 12),
('k-gaming', 'K-Gaming', '게임/e스포츠', '🎮', 13),
('tips', 'Tips', '팁&정보', '💡', 14);

-- ---------------------------------------------------------------------------
-- 게시글 (이미지: image_filename — uploads 폴더 저장 파일명)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS post (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    member_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    content TEXT,
    image_filename VARCHAR(255) DEFAULT NULL,
    view_count INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES category(id),
    FOREIGN KEY (member_id) REFERENCES member(id)
);

-- ---------------------------------------------------------------------------
-- 댓글
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS comment (
    id INT AUTO_INCREMENT PRIMARY KEY,
    post_id INT NOT NULL,
    member_id INT NOT NULL,
    content TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (post_id) REFERENCES post(id) ON DELETE CASCADE,
    FOREIGN KEY (member_id) REFERENCES member(id)
);

-- ---------------------------------------------------------------------------
-- 테스트 회원 (비밀번호 평문: 1234 — 운영 전 반드시 변경·삭제)
-- ---------------------------------------------------------------------------
INSERT IGNORE INTO member (email, password, name, nationality, language) VALUES
('tourist@test.com', '1234', 'John', 'USA', 'en'),
('visitor@test.com', '1234', '田中', 'Japan', 'ja');

-- =============================================================================
-- 참고: 예전에 만든 DB에 post에 image_filename 이 없을 때만 아래 한 줄 실행
-- ALTER TABLE post ADD COLUMN image_filename VARCHAR(255) DEFAULT NULL AFTER content;
-- =============================================================================
-- 끝
-- =============================================================================
