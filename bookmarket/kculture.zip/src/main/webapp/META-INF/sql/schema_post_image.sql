-- 기존 DB에 게시글 이미지 컬럼 추가 (이미 schema.sql 최신이면 생략)
USE kculture_platform;

ALTER TABLE post ADD COLUMN image_filename VARCHAR(255) DEFAULT NULL AFTER content;
