<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List" %>
<%@ page import="model.*" %>
<%
    String error = (String) request.getAttribute("error");
    PostDTO post = (PostDTO) request.getAttribute("post");
    List<CategoryDTO> categories = (List<CategoryDTO>) request.getAttribute("categories");
    String ctx = request.getContextPath();
    if (post == null) { response.sendRedirect(ctx + "/list.do"); return; }
    if (categories == null) categories = java.util.Collections.emptyList();
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Edit Post - K-Culture Platform</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', 'Malgun Gothic', sans-serif; background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%); min-height: 100vh; color: #eee; }
        .header { background: rgba(0,0,0,0.3); padding: 16px 24px; }
        .header a { color: #eee; text-decoration: none; }
        .container { max-width: 700px; margin: 0 auto; padding: 24px; }
        h1 { margin-bottom: 24px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 12px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.2); background: rgba(0,0,0,0.3); color: #eee; }
        .form-group input[type="file"] { padding: 10px; cursor: pointer; }
        .form-group textarea { min-height: 200px; resize: vertical; }
        .post-image-preview { max-width: 100%; max-height: 240px; border-radius: 8px; margin-top: 8px; object-fit: contain; background: rgba(0,0,0,0.2); }
        .hint { font-size: 0.85em; color: #888; margin-top: 6px; }
        .error { color: #e94560; margin-bottom: 16px; }
        .check-row { display: flex; align-items: center; gap: 8px; margin-top: 8px; }
        .check-row input { width: auto; }
        .btn { padding: 12px 24px; border-radius: 8px; border: none; cursor: pointer; font-size: 14px; text-decoration: none; display: inline-block; }
        .btn-primary { background: #e94560; color: #fff; }
        .btn-secondary { background: rgba(255,255,255,0.2); color: #eee; margin-left: 12px; }
    </style>
</head>
<body>
    <div class="header"><a href="<%= ctx %>/view.do?id=<%= post.getId() %>">← Back</a></div>
    <div class="container">
        <h1>✏️ Edit Post</h1>
        <% if (error != null) { %><div class="error"><%= error %></div><% } %>
        <form action="<%= ctx %>/editProcess.do" method="post" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<%= post.getId() %>">
            <div class="form-group">
                <label>Title</label>
                <input type="text" name="title" value="<%= post.getTitle() %>" required>
            </div>
            <div class="form-group">
                <label>Content</label>
                <textarea name="content"><%= post.getContent() != null ? post.getContent() : "" %></textarea>
            </div>
            <div class="form-group">
                <label>Image</label>
                <% if (post.getImageFilename() != null && !post.getImageFilename().isEmpty()) { %>
                    <div><img class="post-image-preview" src="<%= ctx %>/uploads/<%= post.getImageFilename() %>" alt=""></div>
                    <label class="check-row"><input type="checkbox" name="removeImage" value="1"> Remove current image</label>
                <% } %>
                <input type="file" name="image" accept="image/jpeg,image/png,image/gif,image/webp">
                <p class="hint">Leave empty to keep current image. JPEG, PNG, GIF, WebP · max 5MB</p>
            </div>
            <div>
                <button type="submit" class="btn btn-primary">Save</button>
                <a href="<%= ctx %>/view.do?id=<%= post.getId() %>" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</body>
</html>
