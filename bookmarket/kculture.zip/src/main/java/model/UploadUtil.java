package model;

import jakarta.servlet.http.Part;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;

public final class UploadUtil {

    private static final long MAX_BYTES = 5 * 1024 * 1024;

    private UploadUtil() {}

    public static String savePostImage(Part part, Path uploadDir) throws IOException {
        if (part == null || part.getSize() <= 0) {
            return null;
        }
        if (part.getSize() > MAX_BYTES) {
            throw new IOException("Image exceeds 5MB limit.");
        }
        String submitted = part.getSubmittedFileName();
        if (submitted == null || submitted.isBlank()) {
            return null;
        }
        String ext = safeExtension(submitted);
        if (ext == null) {
            return null;
        }
        String ct = part.getContentType();
        if (ct != null && !allowedContentType(ct)) {
            return null;
        }

        Files.createDirectories(uploadDir);
        String filename = UUID.randomUUID().toString().replace("-", "") + "." + ext;
        Path target = uploadDir.resolve(filename).normalize();
        if (!target.startsWith(uploadDir.normalize())) {
            throw new IOException("Invalid upload path.");
        }
        try (InputStream in = part.getInputStream()) {
            Files.copy(in, target);
        }
        return filename;
    }

    public static void deleteIfExists(Path uploadDir, String filename) {
        if (filename == null || filename.isEmpty()) {
            return;
        }
        if (filename.contains("..") || filename.indexOf('/') >= 0 || filename.indexOf('\\') >= 0) {
            return;
        }
        try {
            Path base = uploadDir.normalize();
            Path p = base.resolve(filename).normalize();
            if (p.startsWith(base)) {
                Files.deleteIfExists(p);
            }
        } catch (Exception ignored) {
        }
    }

    private static boolean allowedContentType(String ct) {
        return "image/jpeg".equalsIgnoreCase(ct)
                || "image/png".equalsIgnoreCase(ct)
                || "image/gif".equalsIgnoreCase(ct)
                || "image/webp".equalsIgnoreCase(ct);
    }

    private static String safeExtension(String name) {
        int i = name.lastIndexOf('.');
        if (i < 0 || i >= name.length() - 1) {
            return null;
        }
        String ext = name.substring(i + 1).toLowerCase();
        return switch (ext) {
            case "jpg", "jpeg" -> "jpg";
            case "png" -> "png";
            case "gif" -> "gif";
            case "webp" -> "webp";
            default -> null;
        };
    }
}
