# `model` 패키지 파일별 분석

경로: `src/main/java/model/`  
역할: DB 연결·CRUD(DAO/DTO)·단일 서블릿(Front Controller)·파일 업로드 유틸을 한 패키지에 둔 구조입니다.

---

## 패키지 구성 한눈에

| 구분 | 파일 |
|------|------|
| 인프라 | `DBConnection.java` |
| DTO (값 객체) | `MemberDTO`, `CategoryDTO`, `PostDTO`, `CommentDTO` |
| DAO (DB 접근) | `MemberDAO`, `CategoryDAO`, `PostDAO`, `CommentDAO` |
| 웹 계층 | `FrontController.java` |
| 유틸 | `UploadUtil.java` |

의존 방향: **`FrontController` → DAO / UploadUtil → `DBConnection`**, DTO는 DAO와 JSP 사이에서 전달됩니다.

---

## 1. `DBConnection.java`

**역할:** MySQL JDBC 연결을 만들고, `Connection` / `PreparedStatement` / `ResultSet`을 안전하게 닫는 헬퍼입니다.

**주요 내용**

- 상수: 드라이버 `com.mysql.cj.jdbc.Driver`, URL `jdbc:mysql://localhost:3306/kculture_platform` (타임존·UTF-8 쿼리 파라미터 포함), 사용자 `root`, 비밀번호 하드코딩.
- `getConnection()`: `Class.forName` 후 `DriverManager.getConnection`.
- `close(...)`: 오버로드 3종 — `(conn, pstmt, rs)`, `(conn, pstmt)`, `(conn)` — 예외 시 `printStackTrace`만 수행.

**분석 메모:** 접속 정보가 소스에 고정되어 있어 환경마다 수정이 필요합니다. 운영 환경에서는 외부 설정으로 분리하는 편이 좋습니다.

---

## 2. `MemberDTO.java`

**역할:** `member` 테이블 한 행(또는 그에 대응하는 데이터)을 자바 객체로 옮기기 위한 빈입니다.

**필드**

| 필드 | 의미 |
|------|------|
| `id` | PK |
| `email`, `password` | 로그인·식별 (비밀번호는 평문 저장 가정) |
| `name`, `nationality`, `language` | 프로필 |

getter/setter만 있고 비즈니스 로직은 없습니다.

---

## 3. `MemberDAO.java`

**역할:** `member` 테이블에 대한 SQL 실행을 담당합니다. 모든 메서드가 `DBConnection`으로 연결을 열고 작업 후 `close`합니다.

**메서드**

| 메서드 | SQL·동작 |
|--------|-----------|
| `login(email, password)` | `WHERE email=? AND password=?` — 평문 비교 |
| `join(dto)` | `INSERT` 후 `RETURN_GENERATED_KEYS`로 새 `id` 반환. `language`가 null이면 `"en"` 저장 |
| `findById(id)` | `SELECT *` 단건 |
| `existsEmail(email)` | `COUNT(*)` 로 중복 여부 |
| `mapMember(rs)` | private — `ResultSet` → `MemberDTO` 매핑 |

**분석 메모:** 비밀번호 해시 없이 DB와 직접 비교하는 구조입니다. 학습/로컬용으로는 단순하지만 보안 요구가 있으면 해시·솔트 도입이 필요합니다.

---

## 4. `CategoryDTO.java`

**역할:** `category` 테이블 한 행 표현.

**필드:** `id`, `code`, `nameEn`, `nameKo`, `icon`, `sortOrder` — DB 컬럼 `name_en`, `name_ko`, `sort_order`와 대응(DAO에서 매핑).

---

## 5. `CategoryDAO.java`

**역할:** `category` 테이블 조회 전용에 가깝습니다.

**메서드**

| 메서드 | 설명 |
|--------|------|
| `list()` | `ORDER BY sort_order` 전체 목록 |
| `findById(id)` | PK 조회 |
| `findByCode(code)` | 코드로 조회 |
| `mapCategory(rs)` | private — 스네이크 케이스 컬럼 → camelCase DTO |

---

## 6. `PostDTO.java`

**역할:** `post` 테이블 데이터 + 화면용 JOIN 결과를 한 객체에 담습니다.

**필드**

- **DB 직매핑:** `id`, `categoryId`, `memberId`, `title`, `content`, `imageFilename`, `viewCount`, `createdAt`, `updatedAt`
- **JOIN/표시용:** `memberName`, `categoryName`, `categoryIcon` — `PostDAO`의 SELECT 별칭과 맞춤

---

## 7. `PostDAO.java`

**역할:** 게시글 CRUD와 목록·페이징·조회수 증가를 처리합니다. `member`, `category`와 JOIN하여 작성자명·카테고리명·아이콘을 채웁니다.

**메서드**

| 메서드 | 설명 |
|--------|------|
| `list(categoryId, start, size)` | `categoryId > 0`이면 해당 카테고리만 필터. `ORDER BY created_at DESC LIMIT ?, ?` |
| `count(categoryId)` | 전체 또는 카테고리별 건수 (페이지 수 계산용) |
| `findById(id)` | 상세용 JOIN (상세 쿼리에 `m.nationality` 컬럼도 SELECT — DTO 필드와는 별개로 RS에 존재할 수 있음) |
| `increaseView(id)` | `view_count = view_count + 1` |
| `insert(dto)` | `image_filename` 포함 INSERT, 생성 PK 반환 |
| `update(dto)` | `WHERE id=? AND member_id=?` — 본인 글만 수정 |
| `delete(id, memberId)` | 본인 글만 삭제 |
| `mapPost(rs)` | 컬럼 매핑 + `member_name`, `category_name`, `category_icon`은 try로 감싸 누락 시 무시 |

**분석 메모:** `mapPost`에서 JOIN 별칭이 없는 결과셋에서도 기본 컬럼만으로 동작하도록 확장 필드 세팅을 try 처리한 점이 특징입니다.

---

## 8. `CommentDTO.java`

**역할:** `comment` 테이블 + 목록 표시용 `memberName`, `nationality`(JOIN) 필드.

**필드:** `id`, `postId`, `memberId`, `content`, `createdAt`, `memberName`, `nationality`

---

## 9. `CommentDAO.java`

**역할:** 댓글 목록(게시글별)과 등록입니다.

**메서드**

| 메서드 | 설명 |
|--------|------|
| `listByPostId(postId)` | `comment` JOIN `member`, `ORDER BY created_at` |
| `insert(dto)` | `post_id`, `member_id`, `content` INSERT, 생성 id 반환 |
| `mapComment(rs)` | `member_name`, `nationality`는 try로 선택 매핑 |

---

## 10. `UploadUtil.java`

**역할:** 서블릿 `Part`로 넘어온 이미지를 디스크에 저장하고, 기존 파일 삭제 시 경로 조작을 막습니다. **DB를 사용하지 않습니다.**

**특징**

- `final` 클래스, private 생성자 — static 유틸만 제공.
- 최대 크기 5MB (`MAX_BYTES`), 허용 `Content-Type`: jpeg, png, gif, webp.
- 확장자는 파일명에서 추출 후 화이트리스트(`jpg`/`jpeg` → 저장 파일명은 `jpg`).
- 저장 파일명: UUID + 확장자, `uploadDir` 이하로만 쓰기(경로 traversal 방지).
- `deleteIfExists`: `..`, `/`, `\` 포함 파일명 거부 후 `uploadDir` 하위만 삭제.

**호출처:** `FrontController`의 `writeProcess`, `editProcess`, `delete`(글 삭제 시 이미지 파일 제거).

---

## 11. `FrontController.java`

**역할:** `@WebServlet("*.do")` + `@MultipartConfig`로 **모든 `*.do` 요청의 단일 진입점**입니다. URI 마지막 세그먼트에서 `action` 이름을 뽑아 `switch`로 분기합니다.

**공통 처리**

- `request` UTF-8, 응답 HTML UTF-8.
- 매 요청 `CategoryDAO.list()` → `request.setAttribute("categories", ...)`.
- 인증이 필요한 동작은 `session`의 `loginMember`(`MemberDTO`) 검사.
- 성공/실패에 따라 `RequestDispatcher.forward` 또는 `sendRedirect`.
- 업로드 디렉터리: `getServletContext().getRealPath("/uploads")`, 없으면 임시 디렉터리 하위 `kculture_uploads`.

**의존:** `MemberDAO`, `CategoryDAO`, `PostDAO`, `CommentDAO`, `UploadUtil`, 각종 DTO.

**분석 메모:** MVC에서 Controller에 해당하며, 현재 패키지명은 `model`이지만 역할은 **웹·애플리케이션 계층**에 가깝습니다. 규모가 커지면 `controller` 패키지로 분리하는 경우가 많습니다.

---

## 클래스 간 관계 (요약)

```text
FrontController
    ├── MemberDAO ──► MemberDTO
    ├── CategoryDAO ──► CategoryDTO
    ├── PostDAO ──► PostDTO
    ├── CommentDAO ──► CommentDTO
    └── UploadUtil (파일 시스템)

모든 DAO ──► DBConnection ──► MySQL (kculture_platform)
```

---

*이 문서는 해당 시점의 소스 기준으로 작성되었습니다. SQL 스키마는 `src/main/webapp/META-INF/sql/` 을 참고하세요.*
