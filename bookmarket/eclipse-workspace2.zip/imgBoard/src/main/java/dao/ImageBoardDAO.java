package dao;

import java.sql.*;

import dto.ImageBoardDTO;

public class ImageBoardDAO {
	private Connection conn;
	
	public ImageBoardDAO(Connection conn) {
		this.conn = conn;
	}
	
	public int insertBoard(ImageBoardDTO board) throws SQLException {
		String sql = "insert into jsp_image_board (title, content, writer, password, image_file, image_original) VALUES (?, ?, ?, ?, ?, ?)";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			// 저장하자마자 DB 가 자동으로 부여한 번호를 가져오도록 설정
			pstmt.setString(1, board.getTitle());
			pstmt.setString(2, board.getContent());
            pstmt.setString(3, board.getWriter());
            pstmt.setString(4, board.getPassword());
            pstmt.setString(5, board.getImageFile());
            pstmt.setString(6, board.getImageOriginal());
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
            return 0;
		} finally {
			if (rs != null) rs.close();
            if (pstmt != null) pstmt.close();
		}
	}
}
