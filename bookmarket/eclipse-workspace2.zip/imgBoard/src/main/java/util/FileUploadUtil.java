package util;

import jakarta.servlet.http.Part;  // Tomcat 10.1+ 호환 (javax.servlet → jakarta.servlet)
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

public class FileUploadUtil {
	// 업로드 디렉토리 경로
	private static final String UPLOAD_DIR = "upload/images";
	
	// 허용된 이미지 확장자
	private static final String[] ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp"};
	
	// 최대 파일 크기 (10MB)
    private static final long MAX_FILE_SIZE = 10 * 1024 * 1024;
    
    // 파일 업로드 처리
    public static String uploadFile(Part part, String uploadPath) {
    	if(part == null || part.getSize() == 0) {
    		return null;
    	}
    	
    	try {
        	String originalFileName = getFileName(part);
        	if (originalFileName == null || originalFileName.isEmpty()) {
                return null;
            }
        	
        	// 확장자 확인
        	String extension = getFileExtension(originalFileName);
            if (!isAllowedExtension(extension)) {
                throw new IllegalArgumentException("허용되지 않은 파일 형식입니다: " + extension);
            }
            // 파일 크기 확인
            if (part.getSize() > MAX_FILE_SIZE) {
                throw new IllegalArgumentException("파일 크기가 너무 큽니다. (최대 10MB)");
            }
            
         // 업로드 디렉토리 생성
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();
            }
            
            // 고유한 파일명 생성
            String savedFileName = generateUniqueFileName(originalFileName);
            String filePath = uploadPath + File.separator + savedFileName;
        	// 윈도어에서는 '/' 리눅스 '\' 로 파일 나눔
            // File.separator : 운영체제에 따라 변경
            
         // 파일 저장
            try (InputStream input = part.getInputStream();
                 OutputStream output = new FileOutputStream(filePath)) {
                
                byte[] buffer = new byte[1024];
                int bytesRead;
                while ((bytesRead = input.read(buffer)) != -1) {
                    output.write(buffer, 0, bytesRead);
                }
            }
            
    		return savedFileName;
        } catch(Exception e) {
        	e.printStackTrace();
        	return null;
        }
    }

	private static String getFileName(Part part) {
		String contentDisposition = part.getHeader("content-disposition");
		// getHeader() : form-data; name="image"; filename="my_cat.jpg" 와 같이 파일정보 가져옴
		
		if(contentDisposition == null) {
			return null;
		}
		String[] tokens = contentDisposition.split(";");
		// [form-data], [ name="image"], [ filename="my_cat.jpg"]
		
		for(String token : tokens) {
			if (token.trim().startsWith("filename")) {
                String fileName = token.substring(token.indexOf("=") + 2, token.length() - 1);
                // 경로에서 파일명만 추출
                return fileName.substring(fileName.lastIndexOf("\\") + 1);
                // (C:\Users\Desktop\my_cat.jpg)를 통째로 보냅니다.
                // 진짜 파일명만 추출
                
                // String fileName = part.getSubmittedFileName();
                // 서블릿 3.1 이상이면 한줄로 파일명을 추출 가능
            }
		}
		
		return null;
	}
	
	private static String getFileExtension(String fileName) {
		int lastDot = fileName.lastIndexOf(".");
        if (lastDot == -1) {
            return "";
        }
        // photo.jpg -> .jpg 만 추출
        return fileName.substring(lastDot).toLowerCase();
	}
	
	private static boolean isAllowedExtension(String extension) {
		for (String allowed : ALLOWED_EXTENSIONS) {
            if (allowed.equalsIgnoreCase(extension)) {
                return true;
            }
        }
		
		return false;
	}
	
	private static String generateUniqueFileName(String originalFileName) {
		String extension = getFileExtension(originalFileName);  // 확장명 추출
		String timestamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        String uuid = UUID.randomUUID().toString().substring(0, 8);
        return timestamp + "_" + uuid + extension;
        // {타임스탬프}_{UUID8자리}{확장자}
        // 원본 photo.jpg -> 20260310123456_asfa2345.jpg
	}
	
	public static String getUploadDir() {
        return UPLOAD_DIR;
    }
}
