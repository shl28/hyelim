<%@ page contentType="text/html; charset=utf-8"%>
<%@ page import="jakarta.servlet.http.Cookie" %>

<html>
<head>
<title>쿠키 수정</title>
</head>
<body>

<%
Cookie[] cookies = request.getCookies();

if(cookies != null){

    for(int i=0;i<cookies.length;i++){

        if(cookies[i].getName().equals("userID")){
            
            cookies[i].setValue("manager"); // 값 변경
            response.addCookie(cookies[i]);

            out.println("userID 쿠키가 manager로 수정되었습니다.<br>");
        }

    }

}else{
    out.println("쿠키가 없습니다.");
}
%>

<a href="cookie2.jsp">쿠키 확인</a>

</body>
</html>