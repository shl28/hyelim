<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ page import="com.oreilly.servlet.*" %>
<%@ page import="com.oreilly.servlet.multipart.*" %>
<%@ page import="java.util.*" %>
<%@ page import="java.io.*" %>

<%
// 1. 파일을 저장할 실제 서버 경로
	String savePath = request.getServletContext().getRealPath("/resouce/images");
// 2. 해당 경로에 폴더가 없으면 자동으로 생성
	File saveDir = new File(savePath);
	if(!saveDir.exists()){
		saveDir.mkdirs();
	}
// 3. 설정값 지정
	int maxSize = 5 * 1024 * 1024; // 5MB로 제한
	String encoding = "UTF-8";
	
	try{
//4. MultipartRequest 객체 생성(이순간 파일 업로드가 완료됨)
		MultipartRequest multi = new MultipartRequest(
			request,
			savePath,
			maxSize,
			encoding,
			new DefaultFileRenamePolicy()  // 동일한 파일명 있을 경우, 이름 변경
			);
// 5. 폼에서 전달된 일반 텍스트 데이터 받기 (request 대신 multi 사용)
	String name = multi.getParameter("name");
	String subject = multi.getParameter("subject");
	
// 6. 업로드된 파일 정보 받기
	String fileName = multi.getFilesystemName("filename");  // 서버에 저장된 실제 이름
	String originalFileName = multi.getOriginalFileName("filename"); // 사용자가 올린 원래 이름  
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
	<style>
	    .result-card { width: 500px; margin: 30px auto; padding: 20px; border: 1px solid #ddd; border-radius: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
	    .thumbnail { max-width: 100%; height: auto; border-radius: 5px; margin-top: 15px; }
	    h2 { color: #333; }
	</style>
</head>
<body>
	<h2>파일 업로드 성공!</h2>
	<hr>
	<p><strong>이름:</strong><%= name %> </p>
	<p><strong>제목:</strong><%= subject %> </p>
	<p><strong>원본 파일명:</strong><%= originalFileName %> </p>
	<p><strong>저장 파일명:</strong><%= fileName %> </p>
	<p><strong>저장 경로:</strong> <br><small><%= savePath %></small></p>
	
	<hr>
	<h3>미리보기</h3>
	<%-- 이미지 아닌 경우 확장자 체크가 실제 서비스에서는 필요함 --%>
	<img src="resouce/images/<%= fileName %>" alt="업로드 이미지" class="thumbnail">
</body>
</html>

<%
	} catch (Exception e) {
		e.printStackTrace();
		out.println("<h3>오류 발생</h3>");
		out.println("<p>" + e.getMessage() + "</p>");
	}
%>