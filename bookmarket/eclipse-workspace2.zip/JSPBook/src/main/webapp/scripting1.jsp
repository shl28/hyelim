<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>


<%! int count = 0; %>

<body>
	Page Count is
	<%-- 스크립틀릿 태그 --%>
	<%
		out.println(myMethod(0));
	%>
	<%-- 선언문 태그 --%>
	<%! 
		public int myMethod(int count) {
			return ++count;
	}
	%>
</body>
</html>