<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<script type="text/javascript">
	//function checkForm(){
		//alert("아이디 : " + document.loginForm.id.value + "\n" + 
			//	"비밀번호 : " + document.loginForm.passwd.value);
	//}
	
	// onClick return 사용하는 방법
	function checkLogin(event){
		event.preventDefault();  //기본 동작(제출-submit) 방지
		
		var form = document.loginForm;
		
		if(form.id.value === ""){
			alert("아이디를 입력해 주세요.");
			form.id.focus();
			return false;
		} else if(form.passwd.value === "") {
			alert("비밀번호를 입력해 주세요.");
			form.passwd.focus();
			return false;
		}
		
		form.submit();  // 검증 통과 시 수동 제출
	}
</script>
</head>
<body>
	<form name="loginForm" action="validation02_process.jsp" method="post">
		<p>아이디 : <input type="text" name="id">
		<p>비밀번호 : <input type="password" name="passwd">
		<p><input type="submit" value="전송" onclick="checkLogin(event)">
	</form>
</body>
</html>