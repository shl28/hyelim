<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Validation 수정본</title>
<script type="text/javascript">
    function checkMember() {
        
        // ========== 정규식 패턴 정의 ==========
        // ✅ 수정 1: 파이프 제거
        var regExpId = /^[a-zA-Z]/;
        var regExpName = /^[가-힣]+$/;      // ✅ 수정 2: + 사용
        var regExpPasswd = /^[0-9]+$/;     // ✅ 수정 3: + 사용
        var regExpPhone = /^\d{3}-\d{3,4}-\d{4}$/;
        var regExpEmail = /^[0-9a-zA-Z]([-_\.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_\.]?[0-9a-zA-Z])*\.[a-zA-Z]{2,3}$/i;
        
        var form = document.Member;
        
        // 값 가져오기 (trim 추가)
        var id = form.id.value.trim();
        var name = form.name.value.trim();
        var passwd = form.passwd.value;
        var phone1 = form.phone1.value;
        var phone2 = form.phone2.value.trim();
        var phone3 = form.phone3.value.trim();
        var phone = phone1 + "-" + phone2 + "-" + phone3;  // ✅ 변수명 확인
        var email = form.email.value.trim();
        
        // ========== 아이디 검증 ==========
        // ✅ 수정 4: 빈 값 검증 추가
        if(id === ""){
            alert("아이디를 입력해 주세요!");
            form.id.focus();
            return false;
        }
        
        if (!regExpId.test(id)) {
            alert("아이디는 문자로 시작해 주세요!");
            form.id.focus();
            return false;
        }
        
        // ========== 이름 검증 ==========
        // ✅ 수정 4: 빈 값 검증 추가
        if(name === ""){
            alert("이름을 입력해 주세요!");
            form.name.focus();
            return false;
        }
        
        if (!regExpName.test(name)) {
            alert("이름은 한글만으로 입력해 주세요!");
            form.name.focus();
            return false;
        }
        
        // ========== 비밀번호 검증 ==========
        // ✅ 수정 4: 빈 값 검증 추가
        if(passwd === ""){
            alert("비밀번호를 입력해 주세요!");
            form.passwd.focus();
            return false;
        }
        
        // ✅ 수정 5: 길이 검증 추가
        if(passwd.length < 4){
            alert("비밀번호는 4자 이상 입력해 주세요!");
            form.passwd.focus();
            return false;
        }
        
        if (!regExpPasswd.test(passwd)) {
            alert("비밀번호는 숫자만으로 입력해 주세요!");
            form.passwd.focus();
            return false;
        }
        
        // ========== 전화번호 검증 ==========
        // ✅ 수정 4: 각 필드 빈 값 검증 추가
        if(phone1 === "" || phone2 === "" || phone3 === ""){
            alert("연락처를 모두 입력해 주세요!");
            if(phone1 === "") form.phone1.focus();
            else if(phone2 === "") form.phone2.focus();
            else form.phone3.focus();
            return false;
        }
        
        // ✅ 수정 2: 변수명 수정 (콜 → phone)
        if (!regExpPhone.test(phone)) {
            alert("연락처 입력을 확인해 주세요!\n예: 010-1234-5678");
            form.phone2.focus();
            return false;
        }
        
        // ========== 이메일 검증 ==========
        // ✅ 수정 4: 빈 값 검증 추가
        if(email === ""){
            alert("이메일을 입력해 주세요!");
            form.email.focus();
            return false;
        }
        
        if (!regExpEmail.test(email)) {
            alert("이메일 입력을 확인해 주세요!\n예: example@email.com");
            form.email.focus();
            return false;
        }
    
        // ✅ 수정 6: return true 사용 (onsubmit과 함께 사용)
        return true;
    }
</script>
</head>
<body>
    <h3>회원 가입</h3>
    <form name="Member" action="validation05_process.jsp" method="post" 
          onsubmit="return checkMember()">
        <p>아이디 : <input type="text" name="id">
        <p>비밀번호 : <input type="password" name="passwd">
        <p>이름 : <input type="text" name="name">
        <p>연락처 : 
            <select name="phone1">
                <option value="">선택</option>
                <option value="010">010</option>
                <option value="011">011</option>
                <option value="016">016</option>
                <option value="017">017</option>
                <option value="019">019</option>
            </select> - 
            <input type="text" maxlength="4" size="4" name="phone2"> - 
            <input type="text" maxlength="4" size="4" name="phone3">
        <p>이메일 : <input type="text" name="email">
        <p><input type="submit" value="가입하기">
    </form>
</body>
</html>