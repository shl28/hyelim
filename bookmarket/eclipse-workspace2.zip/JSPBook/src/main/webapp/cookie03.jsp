<%@ page contentType="text/html; charset=utf-8"%>
<%@ page import="jakarta.servlet.http.Cookie" %>

<html>
<head>
<title>Cookie</title>
</head>
<body>
<%
    Cookie[] cookies = request.getCookies();

    if(cookies != null){
        out.println("현재 설정된 쿠키의 개수 => " + cookies.length + "<br>");
        out.println("==========================<br>");

        for (int i = 0; i < cookies.length; i++) {
        	cookies[i].setMaxAge(0);
        	out.println("설정된 쿠키 이름 [" + i + "] : " + cookies[i].getName() + "<br>");
            out.println("설정된 쿠키 값 [" + i + "] : " + cookies[i].getValue() + "<br>");
            out.println("---------------------------------------------<br>");
        }
    } else {
        out.println("설정된 쿠키가 없습니다.");
    }
%>
</body>
</html>