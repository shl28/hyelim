<%@ page contentType="text/html; charset=utf-8"%>
<%@ page import="jakarta.servlet.http.Cookie" %>

<html>
<head>
<title>쿠키 삭제</title>
</head>
<body>

<%
Cookie[] cookies = request.getCookies();

if(cookies != null){

    for(int i=0;i<cookies.length;i++){

        cookies[i].setMaxAge(0); // 삭제
        response.addCookie(cookies[i]);

    }

    out.println("모든 쿠키가 삭제되었습니다.");

}else{
    out.println("삭제할 쿠키가 없습니다.");
}
%>

<br><br>
<a href="cookie2.jsp">쿠키 확인</a>

</body>
</html>