<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<h3>이파일은 second2.jsp 입니다.</h3>
	Today is : <%= request.getParameter("date") %>
</body>
</html>