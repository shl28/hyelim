<%@ page contentType="text/html; charset=utf-8"%>
<%@ page import="jakarta.servlet.http.Cookie" %>

<html>
<head>
<title>쿠키 확인</title>
</head>
<body>

<%
Cookie[] cookies = request.getCookies();

if(cookies != null){

    out.println("현재 쿠키 개수 : " + cookies.length + "<br>");
    out.println("===========================<br>");

    for(int i=0;i<cookies.length;i++){
        out.println("쿠키 이름 : " + cookies[i].getName() + "<br>");
        out.println("쿠키 값 : " + cookies[i].getValue() + "<br>");
        out.println("--------------------------<br>");
    }

}else{
    out.println("쿠키가 없습니다.");
}
%>

<a href="cookie3.jsp">쿠키 수정</a><br>
<a href="cookie4.jsp">쿠키 삭제</a>

</body>
</html>