<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ page import="java.text.* " %>
<%@ page import="java.util.* " %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<h3>현재 로케일의 국가, 날짜, 통화</h3>
	<%
		Locale locale = request.getLocale();  // 브라우저의 헤더를 읽어 현재 국가 확인
		Date currentDate = new Date();
		DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.FULL, locale);
		// 날짜를 현재 국가의 관례 형식에 맞게 출력
		NumberFormat numberFormat = NumberFormat.getNumberInstance(locale);
		// NumberFormat 숫자에 쉼표나 소수점 찍는 방식
	%>
	<p>국가 : <%= locale.getDisplayCountry() %>
	<p>날짜 : <%= dateFormat.format(currentDate) %>
	<p>숫자(12345.67) : <%= numberFormat.format(12345.67) %>
</body>
</html>