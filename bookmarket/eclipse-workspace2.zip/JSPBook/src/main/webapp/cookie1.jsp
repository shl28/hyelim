<%@ page contentType="text/html; charset=utf-8"%>
<%@ page import="jakarta.servlet.http.Cookie" %>

<html>
<head>
<title>쿠키 생성</title>
</head>
<body>

<%
Cookie cookie1 = new Cookie("userID","admin");
Cookie cookie2 = new Cookie("userPW","1234");

cookie1.setMaxAge(60*60); // 1시간
cookie2.setMaxAge(60*60);

response.addCookie(cookie1);
response.addCookie(cookie2);

out.println("쿠키 생성 완료 <br>");
%>

<a href="cookie2.jsp">쿠키 확인</a>

</body>
</html>