<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<script type="text/javascript">
	//function checkForm(){
		//alert("아이디 : " + document.loginForm.id.value + "\n" + 
			//	"비밀번호 : " + document.loginForm.passwd.value);
	//}
	
	// onClick return 사용하는 방법
	function checkLogin(){
		
		var form = document.loginForm;
		
		if(form.id.value === ""){
			alert("아이디를 입력해 주세요.");
			form.id.focus();
			return false;
		} else if(form.passwd.value === "") {
			alert("비밀번호를 입력해 주세요.");
			form.passwd.focus();
			return false;
		}
		return true;
	//	form.submit();
		
		// checkLogin() 함수 : 검증 실패 시 false 반환, 성공 시 true 반환
	}
</script>
</head>
<body>
	<form name="loginForm" action="validation02_process.jsp" method="post">
		<p>아이디 : <input type="text" name="id">
		<p>비밀번호 : <input type="password" name="passwd">
		<p><input type="submit" value="전송" onclick="return checkLogin()">
	</form>
</body>
</html>