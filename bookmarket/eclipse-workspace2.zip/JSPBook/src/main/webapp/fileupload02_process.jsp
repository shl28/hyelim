<%@ page contentType="text/html; charset=utf-8"%>
<%@ page import="com.oreilly.servlet.*"%>
<%@ page import="com.oreilly.servlet.multipart.*"%>
<%@ page import="java.util.*"%>
<%@ page import="java.io.*"%>
<%
   MultipartRequest multi = new MultipartRequest(request, "C:\\upload", 5 * 1024 * 1024, "utf-8", new DefaultFileRenamePolicy());

   Enumeration params = multi.getParameterNames();
   // params : form 에서 전달된 pameter 이름들을 모아놓은 객체

   while (params.hasMoreElements()) {  // 요소가 없을때까지 
      String name = (String) params.nextElement();  // 요소를 하나씩 꺼내서
      String value = multi.getParameter(name);  
      out.println(name + " = " + value + "<br>");
   }
   out.println("-----------------------------------<br>");

   Enumeration files = multi.getFileNames();
   // 파일 parameter 가져오기

   while (files.hasMoreElements()) {
      String name = (String) files.nextElement();  
      String filename = multi.getFilesystemName(name);  // 서버에 저장된 이름
      String original = multi.getOriginalFileName(name);  // 원래 파일 이름
      String type = multi.getContentType(name);  // 파일 타입
      File file = multi.getFile(name);  // 파일 객체

      out.println("요청 파라미터 이름 : " + name + "<br>");
      out.println("실제 파일 이름 : " + original + "<br>");
      out.println("저장 파일 이름 : " + filename + "<br>");
      out.println("파일 콘텐츠 유형 : " + type + "<br>");

      if (file != null) {
         out.println(" 파일 크기 : " + file.length());
         out.println("<br>");
      }
   }
%>