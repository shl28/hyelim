<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<script type="text/javascript">
	// onsubmit 사용하는 방법 (권장)
	function checkLogin(){
		var form = document.loginForm;
		
		if(form.id.value === ""){
			alert("아이디를 입력해 주세요.");
			form.id.focus();
			return false;
		} else if(form.passwd.value === "") {
			alert("비밀번호를 입력해 주세요.");
			form.passwd.focus();
			return false;
		}
		
		return true;  // 검증 통과 시 true 반환
		
		// onsubmit="return checkLogin()" 폼 제출 시 검증 실행 , false 반환 시 제출(submit) 차단
	}
</script>
</head>
<body>
	<form name="loginForm" action="validation02_process.jsp" method="post" onsubmit="return checkLogin()">
		<p>아이디 : <input type="text" name="id">
		<p>비밀번호 : <input type="password" name="passwd">
		<p><input type="submit" value="전송">
	</form>
</body>
</html>