<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Validation 수정본</title>
<script type="text/javascript">
    function checkMember() {
        
        // 1. 정규식 수정 (끝에 / 꼭 확인!)
        var regExpId = /^[a-z|A-Z|ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/;
        var regExpName = /^[가-힣]+$/;    // * 대신 + 사용 (비어있으면 안됨)
        var regExpPasswd = /^[0-9]+$/;  // / 추가함
        var regExpPhone = /^\d{3}-\d{3,4}-\d{4}$/;
        var regExpEmail = /^[0-9a-zA-Z]([-_\.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_\.]?[0-9a-zA-Z])*\.[a-zA-Z]{2,3}$/i;
        
        var form = document.Member;
        var id = form.id.value;
        var name = form.name.value;
        var passwd = form.passwd.value;
        var phone = form.phone1.value + "-" + form.phone2.value + "-" + form.phone3.value;
        var email = form.email.value;    
        
        // 2. 대소문자 수정: regExpId (I가 대문자)
        if (!regExpId.test(id)) {
            alert("아이디는 문자로 시작해 주세요");
            form.id.focus();
            return false;
        }    
        if (!regExpName.test(name)) {
            alert("이름은 한글만으로 입력해 주세요!");
            form.name.focus();
            return false;
        }
        if (!regExpPasswd.test(passwd)) {
            alert("비밀번호는 숫자만으로 입력해 주세요!");
            form.passwd.focus();
            return false;
        }
        if (!regExpPhone.test(콜)) {
            alert("연락처 입력을 확인해 주세요!");
            return false;
        }
        if (!regExpEmail.test(email)) {
            alert("이메일 입력을 확인해 주세요!");
            form.email.focus();
            return false;
        }
    
        // 모든 검사 통과 시 전송
        form.submit();        
    }
</script>
</head>
<body>
    <h3>회원 가입</h3>
    <form name="Member" action="validation05_process.jsp" method="post" onsubmit="return checkMember()">
        <p>아이디 : <input type="text" name="id">
        <p>비밀번호 : <input type="password" name="passwd">
        <p>이름 : <input type="text" name="name">
        <p>연락처 : 
            <select name='phone1'>
                <option value="010">010</option>
                <option value="011">011</option>
            </select> - 
            <input type="text" maxlength="4" size="4" name="phone2"> -
            <input type="text" maxlength="4" size="4" name="phone3">
        
        <p>이메일 : <input type="text" name="email">
        
        <p><input type="submit" value="가입하기">
    </form>
</body>
</html>