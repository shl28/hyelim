<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<script type="text/javascript">
	function checkMember(){
		var regExpId = /^[a-z|A-Z|ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/;
		var regExpName = /^[가-힣]+$/;  // 완성형 한글 글자
		var regExpPasswd = /^[0-9]*$/;
		var regExpPhone = /^\d{3}-\d{3,4}-\d{4}$/;
		var regExpEmail = /^[0-9a-zA-z]([-_\,]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_\,]?[0-9a-zA-Z])*\.[a-zA-Z]{2,3}$/i;
		// [0-9a-zA-z] 첫글자 영문/숫자
		// 하이픈, 언더스코어, 점 + 영문/숫자 조합
		// @
		// [0-9a-zA-z]  : @뒤에 첫글자는 영문/숫자
		// 하이픈, 언더스코어, 점 + 영문/숫자 조합
		// .
		// [a-zA-Z]{2,3} : 최상위 도메인
		// $문자열 끝
		// i : 대소문자 구분 안함
		
		var form = document.Member;
		var id = form.id.value;
	    var name = form.name.value;
	    var passwd = form.passwd.value;
	    var phone = form.phone1.value + "-" + form.phone2.value + "-" + form.phone3.value;
	    var email = form.email.value; 
		
		if(!regExpId.test(id)){
			alert("아이디는 문자로 시작해주세요.");
			form.id.select();
			return false;
		} 
		
		if(!regExpName.test(name)){
			alert("이름은 한글만으로 입력해주세요.");
			return false;
		} 
		
		if(!regExpPasswd.test(passwd)){
			alert("비밀번호는 숫자만으로 입력해주세요.");
			return false;
		} 
		
		if(!regExpPhone.test(phone)){
			alert("연락처 입력을 확인해 주세요.");
			return false;
		} 
		
		if(!regExpEmail.test(email)){
			alert("이메일 입력을 확인해 주세요.");
			return false;
		} 
		
		form.submit();
		
	}
</script>
</head>
<body>
	<form name="Member" action="validation05_process.jsp" method="post" onsubmit="return checkMember()">
		<p>아이디 : <input type="text" name="id">
		<p>비밀번호 : <input type="password" name="passwd">
		<p>이름 : <input type="text" name="name">
		<p>연락처 : 
		<select name="phone1">
			<option value="010">010</option>
			<option value="011">011</option>
			<option value="016">016</option>
			<option value="017">017</option>
			<option value="019">019</option>
		</select>
		-
		<input type="text" maxlength="4" size="4" name="phone2">
		 -
		<input type="text" maxlength="4" size="4" name="phone3"> 
		<p><input type="submit" value="가입하기">
	</form>
</body>
</html>