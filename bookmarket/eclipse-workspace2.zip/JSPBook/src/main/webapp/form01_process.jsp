<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ page import="java.util.*" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<%
	request.setCharacterEncoding("UTF-8");

	String id = request.getParameter("id");
	String passwd = request.getParameter("passwd");
	String name = request.getParameter("name");
	
	String phone1 = request.getParameter("phone");
	String phone2 = request.getParameter("phone2");
	String phone3 = request.getParameter("phone3");
	
	String sex = request.getParameter("sex");
	
	String[] hobby = request.getParameterValues("hobby");
	
	String comment = request.getParameter("comment");
	
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<h3>회원가입 정보</h3>
	아이디 : <%=id %> <br><br>
	
	비밀번호 : <%=passwd %> <br><br>
	
	이름 : <%=name %> <br><br>
	
	연락처 : <%=phone1 %> - <%=phone2 %> - <%=phone3 %><br><br>
	
	성별 : <%=sex %> <br><br>
	
	취미 : 
	<c:if test="${not empty paramValues.hobby}">
	    <c:forEach var="h" items="${paramValues.hobby}">
	        ${h}
	    </c:forEach>
	</c:if>
	<br><br>
	
	<%-- 
	<%
		if(hobby != null ){
			for(String h : hobby){
			%>
				<%= h %>	
			<% 
			}
		}
	%> 
	
	--%>
	
	
	가입인사 : <%=comment %>
	
</body>
</html>