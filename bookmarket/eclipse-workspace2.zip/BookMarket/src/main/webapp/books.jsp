<%@ page contentType="text/html; charset=utf-8" %>
<%@ page import="java.sql.*"%>
 
 <%-- dao.BookRepository 객체를 생성해서 bookDAO 이름으로 사용하고 세션에 저장  --%>   
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Insert title here</title>
<link rel="stylesheet" href="./resources/css/bootstrap.min.css">
</head>
<body>
   <div class="container py-4">
      <%@ include file="menu.jsp" %>
      
      
      <div class="p-5 mb-4 bg-body-tertiary rounded-3">
         <div class="container-fluid py-5">
              <h1 class="display-5 fw-bold">도서목록</h1>
              <p class="col-md-8 fs-4">BookList</p>      
           </div>
      </div>
      <%@ include file="dbconn.jsp" %>
       <div class="row align-items-md-stretch text-center"> 
          
          <%
	         PreparedStatement pstmt = null;
	      	 ResultSet rs = null;
	      	 
	      	 String sql = "select * from book";
	      	 pstmt = conn.prepareStatement(sql);
	      	 rs = pstmt.executeQuery();
	      	 
	      	 while(rs.next()){
	      %>   
          
          
          <div class="col-md-4">
                <div class="h-100 p-2">  
               <img src="./resources/images/<%= rs.getString("b_fileName")%>" 
               style="width:250px; height:350px"/>
               <h5><b><%= rs.getString("b_name")%></b></h5>
               <p><%= rs.getString("b_author")%>
               <br> <%= rs.getString("b_publisher")%> | <%= rs.getString("b_releaseDate")%>
               <p> <%=rs.getString("b_description").substring(0,60) %>...
               <p><%= rs.getString("b_unitPrice")%>원
               <p><a href="./book.jsp?id=<%= rs.getString("b_id")%>" class="btn btn-secondary" role="button" >상세 정보 &raquo;</a> </p>
            </div>   
         </div>      
       
       <%
       		} 
	      	 if(rs != null)
	      		 rs.close();
	      	 if(pstmt != null)
	      		 pstmt.close();
	      	 if(conn != null)
	      		 conn.close();
       %>
       </div>   
      
      
      <%@ include file="footer.jsp" %>
   </div>
</body>
</html>


