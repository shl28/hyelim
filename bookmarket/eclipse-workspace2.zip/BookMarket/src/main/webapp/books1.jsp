<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ page import="java.util.*"%>
<%@ page import="dao.BookRepository" %>
<%@ page import="dto.Book" %>
 
 <%-- dao.BookRepository 객체를 생성해서 bookDAO 이름으로 사용하고 세션에 저장  --%>   
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<link rel="stylesheet" href="./resources/css/bootstrap.min.css">
</head>
<body>
   <div class="container py-4">
      <%@ include file="menu.jsp" %>
      
      
      <div class="p-5 mb-4 bg-body-tertiary rounded-3">
         <div class="container-fluid py-5">
              <h1 class="display-5 fw-bold">도서목록</h1>
              <p class="col-md-8 fs-4">BookList</p>      
           </div>
      </div>
      <%
         BookRepository dao = BookRepository.getInstance();
         ArrayList<Book> listOfBooks = dao.getAllBooks();
      %>
      
       <div class="row align-items-md-stretch   text-center"> 
       	<%
             for(int i=0; i < listOfBooks.size();i++){
             Book book = listOfBooks.get(i);      
          %>
 
          
          
          <div class="col-md-4">
                <div class="h-100 p-2">   
                
                <%
                	String desc = book.getDescription();
                %>
               <img src="./resources/images/<%=book.getFilename()%>" 
               style="width:250; height:350"/>
               <h5><b><%=book.getName()%></b></h5>
               <p><%=book.getAuthor()%>
               <br> <%=book.getPublisher()%> | <%=book.getReleaseDate()%>
               <p> <%=desc.length() > 60 ? desc.substring(0,60) + "..." : desc %>
               <p><%=book.getUnitPrice()%>원
               <p><a href="./book.jsp?id=<%=book.getBookId()%>" class="btn btn-secondary" role="button" >상세 정보 &raquo;</a> </p>
            </div>   
         </div>      
       
       <%
       		} 
       %>
       </div>   
      
      
      <%@ include file="footer.jsp" %>
   </div>
</body>
</html>


