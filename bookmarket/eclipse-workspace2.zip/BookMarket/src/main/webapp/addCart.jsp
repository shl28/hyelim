<%@ page contentType="text/html; charset=utf-8"%>
<%@ page import="java.util.ArrayList"%>
<%@ page import="dto.Book"%>
<%@ page import="dao.BookRepository"%>

<%
	String id = request.getParameter("id");

	if(id == null || id.trim().equals("")){
		response.sendRedirect("product.jsp");
		return;
	}
	
	BookRepository dao = BookRepository.getInstance();
	
	Book product = dao.getBookById(id);
	if(product == null){
		response.sendRedirect("exceptionNoBookId.jsp");
	}
	
	ArrayList<Book> goodsList = dao.getAllBooks();
	Book goods = new Book();
	
	for(int i = 0; i < goodsList.size(); i++){
		goods = goodsList.get(i);
		
		if(goods.getBookId().equals(id)){
			break;
		}
	}
	
	//세션에서 장바구니 가져오기
	ArrayList<Book> list = (ArrayList<Book>) session.getAttribute("cartlist");
	if(list == null){  // 장바구니 없으면
		list = new ArrayList<Book>();
		session.setAttribute("cartlist", list);
	}
	
	int cnt = 0;
	Book goodsQnt = new Book();
	
	for(int i = 0; i < list.size(); i++){
		goodsQnt = list.get(i);
		
		if(goodsQnt.getBookId().equals(id)){
			cnt++; 
			int orderQuantity = goodsQnt.getQuantity() + 1; // 동일한 도서가 있으면 수량 하나 증가
			goodsQnt.setQuantity(orderQuantity);
		}
	}
	
	if(cnt == 0){  // 장바구니에 같은 책이 없다면
		goods.setQuantity(1);  // 전체 도서 목록에서 찾은 책 goods: 새로 장바구니에 넣을 책
		list.add(goods);
		// goodsQnt : 이미 장바구니에 있는 책
	}
	
	response.sendRedirect("book.jsp?id=" + id);
%>