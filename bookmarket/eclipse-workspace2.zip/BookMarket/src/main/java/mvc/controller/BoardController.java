package mvc.controller;

import java.io.*;
import java.util.*;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import mvc.model.BoardDAO;
import mvc.model.BoardDTO;

// BoardController : 게시판 기능 담당
public class BoardController extends HttpServlet {
	// HttpServlet을 상속 받아 웹요청 처리
	// web.xml 에서 *.do URL 패턴으로 매핑
	private static final long serialVersionUID = 1L;
	static final int LISTCOUNT = 5;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	// get 과 post 모두 doPost에서 처리하도록 함

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String RequestURI = request.getRequestURI(); // 예) /BookMarket/BoardListAction.do
		String contextPath = request.getContextPath(); // 예) /BookMarket
		String command = RequestURI.substring(contextPath.length()); // 예) BoardListAction.do -> 파일명만 남음

		response.setContentType("text/html; charset=utf-8");
		request.setCharacterEncoding("utf-8");

		if (command.equals("/BoardListAction.do")) { // 등록된 글목록 페이지 출력
			requestBoardList(request);
			RequestDispatcher rd = request.getRequestDispatcher("/board/list.jsp");
			rd.forward(request, response);
		} else if (command.equals("/BoardWriteForm.do")) { // 글 등록 페이지
			requestLoginName(request);
			RequestDispatcher rd = request.getRequestDispatcher("./board/writeForm.jsp");
			rd.forward(request, response);
		} else if (command.equals("/BoardWriteAction.do")) { // 새로운 글 등록
			requestBoardWrite(request); // 새 글 저장 후
			RequestDispatcher rd = request.getRequestDispatcher("/BoardListAction.do"); // 목록으로 이동
			rd.forward(request, response);
		} else if (command.equals("/BoardViewAction.do")) {// 선택된 글 상자 페이지 가져오기
			requestBoardView(request);
			RequestDispatcher rd = request.getRequestDispatcher("/BoardView.do");
			rd.forward(request, response);
		} else if (command.equals("/BoardView.do")) { // 글 상세 페이지 출
			RequestDispatcher rd = request.getRequestDispatcher("./board/view.jsp");
			rd.forward(request, response);
		} else if (command.equals("/BoardUpdateAction.do")) { // 선택된 글 수정하기
			requestBoardUpdate(request);
			RequestDispatcher rd = request.getRequestDispatcher("/BoardListAction.do");
			rd.forward(request, response);
		} else if (command.equals("/BoardDeleteAction.do")) { // 선택된 글 삭제하기
			requestBoardDelete(request);
			RequestDispatcher rd = request.getRequestDispatcher("/BoardListAction.do");
			rd.forward(request, response);
		}

	}

	public void requestBoardDelete(HttpServletRequest request) {
		int num = Integer.parseInt(request.getParameter("num"));
		int pageNum = Integer.parseInt(request.getParameter("pageNum"));
		
		BoardDAO dao = BoardDAO.getInstance();
		
		dao.deleteBoard(num);
	}

	public void requestBoardUpdate(HttpServletRequest request) {
		int num = Integer.parseInt(request.getParameter("num"));
		int pageNum = Integer.parseInt(request.getParameter("pageNum"));

		BoardDAO dao = BoardDAO.getInstance();
		BoardDTO board = new BoardDTO();

		board.setNum(num);
		board.setName(request.getParameter("name"));
		board.setSubject(request.getParameter("subject"));
		board.setContent(request.getParameter("content"));

		java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat("yyyy/MM/dd(HH:mm:ss)");
		String regist_day = formatter.format(new java.util.Date());

		board.setHit(0);
		board.setRegist_day(regist_day);
		board.setIp(request.getRemoteAddr());

		dao.updateBoard(board);
	}

	// 상세 페이지 가져오기
	public void requestBoardView(HttpServletRequest request) {
		BoardDAO dao = BoardDAO.getInstance();

		int num = Integer.parseInt(request.getParameter("num")); // 글번호 받아옴 BoardViewAction.do?num=10
		int pageNum = Integer.parseInt(request.getParameter("pageNum")); // 현재 페이지 BoardViewAction.do?num=10&pageNum=3

		BoardDTO board = new BoardDTO();
		board = dao.getBoardByNum(num, pageNum); // dao 에서 게시글 1개 조회

		request.setAttribute("num", num); // request 에 저장
		request.setAttribute("page", pageNum);
		request.setAttribute("board", board);
		// jsp 에서 출력

	}

	// 인증된 사용자명 가져오기
	public void requestLoginName(HttpServletRequest request) {
		String id = request.getParameter("id");

		BoardDAO dao = BoardDAO.getInstance();

		String name = dao.getLoginNameById(id);

		request.setAttribute("name", name);

	}

	public void requestBoardList(HttpServletRequest request) {
		BoardDAO dao = BoardDAO.getInstance();
		ArrayList<BoardDTO> boardlist = new ArrayList<BoardDTO>();

		int pageNum = 1;
		int limit = LISTCOUNT;

		// BoardListAction.do?pageNum=3;
		if (request.getParameter("pageNum") != null) {
			pageNum = Integer.parseInt(request.getParameter("pageNum"));
		}

		String items = request.getParameter("items"); // subject(제목), 글쓴이, 본문 선택
		String text = request.getParameter("text"); // 검색한 내용 (예: "java")
		// 선택한 "제목"에서 "java" 검색

		int total_record = dao.getListCount(items, text);
		boardlist = dao.getBoardList(pageNum, limit, items, text);

		int total_page;

		if (total_record % limit == 0) { // 총 레코드가 20이면 20/5 = 4
			total_page = total_record / limit;
			Math.floor(total_page);
		} else { // 총 레코드가 21이면 21/5 = 4 + 1 => 5페이지
			total_page = total_record / limit;
			Math.floor(total_page);
			total_page = total_page + 1;
		}

		request.setAttribute("pageNum", pageNum);
		request.setAttribute("total_page", total_page);
		request.setAttribute("total_record", total_record);
		request.setAttribute("boardlist", boardlist);
	}

	// 새로운 글 등록하기
	public void requestBoardWrite(HttpServletRequest request) {
		BoardDAO dao = BoardDAO.getInstance();
		BoardDTO board = new BoardDTO();

		board.setId(request.getParameter("id"));
		board.setName(request.getParameter("name"));
		board.setSubject(request.getParameter("subject"));
		board.setContent(request.getParameter("content"));

		System.out.println(request.getParameter("name"));
		System.out.println(request.getParameter("subject"));
		System.out.println(request.getParameter("content"));

		java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat("yyyy/MM/dd(HH:mm:ss)");
		String regist_day = formatter.format(new java.util.Date());

		board.setHit(0);
		board.setRegist_day(regist_day);
		board.setIp(request.getRemoteAddr());

		dao.insertBoard(board);
	}
}
