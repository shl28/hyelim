<%@ page contentType="text/html; charset=utf-8"%>
<%@ page import="java.sql.*"%> 
<%
    Connection conn = null; 

    // 1. 연결 정보 설정 (타임존 설정 추가)
    String url = "jdbc:mysql://localhost:3306/BookMarketDB?serverTimezone=Asia/Seoul&useSSL=false";
    String user = "root";
    String password = "1234";

    try {
        // 2. 최신 MySQL 드라이버 클래스명 (com.mysql.cj.jdbc.Driver)
        Class.forName("com.mysql.cj.jdbc.Driver");
        conn = DriverManager.getConnection(url, user, password);
        
        // 성공 시 확인 메시지 (테스트용, 실제 서비스 시 삭제 권장)
        // out.println("데이터베이스 연결 성공!");
        
    } catch (ClassNotFoundException e) {
        out.println("드라이버를 찾을 수 없습니다: " + e.getMessage());
    } catch (SQLException ex) {
        out.println("데이터베이스 연결 실패!<br>");
        out.println("에러 내용: " + ex.getMessage());
    }
%>