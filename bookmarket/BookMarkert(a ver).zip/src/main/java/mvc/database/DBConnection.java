package mvc.database;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;

public class DBConnection {
	
	public static Connection getConnection() throws SQLException, ClassNotFoundException  {		

Connection conn = null;
        
        // 1. MySQL 8.0 이상에서는 타임존(serverTimezone) 설정을 추가하는 것이 안전합니다.
        // 2. 데이터베이스 이름이 BookMarketDB인지 다시 한번 확인하세요.
        String url = "jdbc:mysql://localhost:3306/BookMarketDB?serverTimezone=UTC&useSSL=false&allowPublicKeyRetrieval=true";
        String user = "root";
        String password = "1234";

        // 3. 최신 MySQL 드라이버 클래스명은 cj가 포함된 경로를 사용합니다.
        // (참고: 최신 JDBC 드라이버는 Class.forName 없이도 로드되지만, 명시하는 것이 관례입니다.)
        Class.forName("com.mysql.cj.jdbc.Driver");
        
        conn = DriverManager.getConnection(url, user, password);
        
        return conn;
    }

    // 연결을 닫는 보조 메소드도 추가해두면 관리가 편합니다.
    public static void close(Connection conn) {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
